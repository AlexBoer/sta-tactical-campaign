﻿/**
 * Campaign Tracker Sheet for STA Tactical Campaign
 * ApplicationV2-based sheet. Turn state lives entirely in the data model
 * (system.turnPhase, system.scenarioPoi, per-POI entry fields) rather than
 * in actor flags.  The progress bar and phase-gated actions are the core UX.
 */

const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;

import { PoiGenerator } from "../poi-generator.mjs";
import { AssetGenerator } from "../asset-generator.mjs";
import { EventEffectResolver } from "../apps/event-effect-resolver.mjs";
import { ProgressionLog } from "../apps/progression-log.mjs";
import { RollTableManager } from "../apps/roll-table-manager.mjs";
import { RollTableManagerService } from "../apps/roll-table-manager-service.mjs";
import {
  expireCampaignTurnEffects,
  replaceAssetStatusEffect,
} from "../active-effect-service.mjs";
import { TrackerNotifier } from "../apps/tracker-notifier.mjs";
import { TurnLog } from "../apps/turn-log.mjs";

const MODULE_ID = "sta-tactical-campaign";

/** Ordered list of top-level wizard phases. */
const PHASES = ["1", "2", "3"];

/** Number of sub-steps in each phase. */
const STEP_COUNTS = { 1: 3, 2: 3, 3: 4 };

/** Top-level phase metadata for the phases progress bar. */
const PHASE_META = {
  1: { label: "STA_TC.Wizard.Phase1" },
  2: { label: "STA_TC.Wizard.Phase2" },
  3: { label: "STA_TC.Wizard.Phase3" },
};

/** Sub-step metadata (label + hint) for the steps progress bar. */
const STEP_META = {
  1: [
    {
      label: "STA_TC.Wizard.Phase1Step1",
      hint: "STA_TC.Wizard.Phase1Step1Hint",
    },
    {
      label: "STA_TC.Wizard.Phase1Step2",
      hint: "STA_TC.Wizard.Phase1Step2Hint",
    },
    {
      label: "STA_TC.Wizard.Phase1Step3",
      hint: "STA_TC.Wizard.Phase1Step3Hint",
    },
  ],
  2: [
    {
      label: "STA_TC.Wizard.Phase2Step1",
      hint: "STA_TC.Wizard.Phase2Step1Hint",
    },
    {
      label: "STA_TC.Wizard.Phase2Step2",
      hint: "STA_TC.Wizard.Phase2Step2Hint",
    },
    {
      label: "STA_TC.Wizard.Phase2Step3",
      hint: "STA_TC.Wizard.Phase2Step3Hint",
    },
  ],
  3: [
    {
      label: "STA_TC.Wizard.Phase3Step1",
      hint: "STA_TC.Wizard.Phase3StepHint1",
    },
    {
      label: "STA_TC.Wizard.Phase3Step2",
      hint: "STA_TC.Wizard.Phase3StepHint2",
    },
    {
      label: "STA_TC.Wizard.Phase3Step3",
      hint: "STA_TC.Wizard.Phase3StepHint3",
    },
    {
      label: "STA_TC.Wizard.Phase3Step4",
      hint: "STA_TC.Wizard.Phase3StepHint4",
    },
  ],
};

export class CampaignTrackerSheet extends HandlebarsApplicationMixin(
  ActorSheetV2,
) {
  /** @override */
  static DEFAULT_OPTIONS = {
    classes: ["sta-tactical-campaign", "campaign-tracker-sheet"],
    actions: {
      startTurn: CampaignTrackerSheet._onStartTurn,
      cancelTurn: CampaignTrackerSheet._onCancelTurn,
      endTurn: CampaignTrackerSheet._onEndTurn,
      nextPhase: CampaignTrackerSheet._onNextPhase,
      prevPhase: CampaignTrackerSheet._onPrevPhase,
      removeAsset: CampaignTrackerSheet._onRemoveAsset,
      openActor: CampaignTrackerSheet._onOpenActor,
      createRandomAsset: CampaignTrackerSheet._onCreateRandomAsset,
      createCustomAsset: CampaignTrackerSheet._onCreateCustomAsset,
      createAssetForType: CampaignTrackerSheet._onCreateAssetForType,
      removePoi: CampaignTrackerSheet._onRemovePoi,
      removePoiAsset: CampaignTrackerSheet._onRemovePoiAsset,
      assignAsset: CampaignTrackerSheet._onAssignAsset,
      generatePoi: CampaignTrackerSheet._onGeneratePoi,
      generateAllPois: CampaignTrackerSheet._onGenerateAllPois,
      createCustomPoi: CampaignTrackerSheet._onCreateCustomPoi,
      removeGeneratedPoi: CampaignTrackerSheet._onRemoveGeneratedPoi,
      recallAsset: CampaignTrackerSheet._onRecallAsset,
      selectScenario: CampaignTrackerSheet._onSelectScenario,
      rollEvent: CampaignTrackerSheet._onRollEvent,
      resetEvent: CampaignTrackerSheet._onResetEvent,
      rollRandomEvent: CampaignTrackerSheet._onRollRandomEvent,
      rollConflict: CampaignTrackerSheet._onRollConflict,
      resetConflictRoll: CampaignTrackerSheet._onResetConflictRoll,
      setConflictResult: CampaignTrackerSheet._onSetConflictResult,
      chooseConsequence: CampaignTrackerSheet._onChooseConsequence,
      chooseFailureOption: CampaignTrackerSheet._onChooseFailureOption,
      rollEscalation: CampaignTrackerSheet._onRollEscalation,
      rollCommandeer: CampaignTrackerSheet._onRollCommandeer,
      rollProgression: CampaignTrackerSheet._onRollProgression,
      chooseProgression: CampaignTrackerSheet._onChooseProgression,
      confirmProgression: CampaignTrackerSheet._onConfirmProgression,
      confirmOutcomeResolved: CampaignTrackerSheet._onConfirmOutcomeResolved,
      confirmOutcomeIntensify: CampaignTrackerSheet._onConfirmOutcomeIntensify,
      confirmOutcomeCatastrophe:
        CampaignTrackerSheet._onConfirmOutcomeCatastrophe,
      confirmOutcomeDiffIncrease:
        CampaignTrackerSheet._onConfirmOutcomeDiffIncrease,
      confirmOutcomeExplorationRemove:
        CampaignTrackerSheet._onConfirmOutcomeExplorationRemove,
      confirmOutcomeExtraPoi: CampaignTrackerSheet._onConfirmOutcomeExtraPoi,
      ignoreOutcome: CampaignTrackerSheet._onIgnoreOutcome,

      clearUnavailable: CampaignTrackerSheet._onClearUnavailable,
      openProgressionLog: CampaignTrackerSheet._onOpenProgressionLog,
      openTurnLog: CampaignTrackerSheet._onOpenTurnLog,
      openRollTableManager: CampaignTrackerSheet._onOpenRollTableManager,
      openPoiTable: CampaignTrackerSheet._onOpenPoiTable,
      setPoiVisibility: CampaignTrackerSheet._onSetPoiVisibility,
      setAllPoiVisibility: CampaignTrackerSheet._onSetAllPoiVisibility,
    },
    form: {
      submitOnChange: true,
      closeOnSubmit: false,
    },
    position: {
      height: 900,
      width: 820,
    },
    window: {
      resizable: true,
      minimizable: true,
    },
    dragDrop: [{ dragSelector: null, dropSelector: null }],
  };

  /** @override */
  static PARTS = {
    sheet: {
      template:
        "modules/sta-tactical-campaign/templates/campaign-tracker-sheet.hbs",
    },
  };

  /** @override */
  get title() {
    return `${this.actor.name} - ${game.i18n.localize("STA_TC.Types.CampaignTracker")}`;
  }

  // ==========================================================================
  // Context Preparation
  // ==========================================================================

  /** @override */
  async _prepareContext(options) {
    const actor = this.actor;
    const system = actor.system;

    const turnPhase = system.turnPhase || "";
    const turnActive = !!turnPhase;
    const scenarioPoi = system.scenarioPoi || "";

    const assetPoiMap = await this._buildAssetPoiMap(system);

    const characterAssets = await this._resolveActorList(
      system.characterAssets,
      assetPoiMap,
    );
    const shipAssets = await this._resolveActorList(
      system.shipAssets,
      assetPoiMap,
    );
    const resourceAssets = await this._resolveActorList(
      system.resourceAssets,
      assetPoiMap,
    );

    const turnStep = system.turnStep || 1;
    const canGeneratePoi = turnActive && turnPhase === "1" && turnStep === 1;
    const canSelectScenario = turnActive && turnPhase === "1" && turnStep === 2;
    const canAssignAssets = turnActive && turnPhase === "1" && turnStep === 2;
    const canRollEvent = turnActive && turnPhase === "1" && turnStep === 3;
    const canRollConflicts = turnActive && turnPhase === "2";
    const isPhase3 = turnActive && turnPhase === "3";

    const poiColumns = await this._resolveAllPoiColumns(system, {
      canSelectScenario,
      canRollEvent,
      canRollConflicts,
      isPhase3,
      scenarioPoi,
    });

    let phaseSteps = [];
    let subSteps = [];
    let phaseHint = "";
    let isFirstPhase = true;
    let isLastPhase = false;

    if (turnActive) {
      phaseSteps = PHASES.map((p, i) => ({
        key: p,
        label: game.i18n.localize(PHASE_META[p].label),
        active: p === turnPhase,
        completed: PHASES.indexOf(p) < PHASES.indexOf(turnPhase),
        index: i + 1,
      }));
      subSteps = (STEP_META[turnPhase] || []).map((s, i) => ({
        label: game.i18n.localize(s.label),
        active: i + 1 === turnStep,
        completed: i + 1 < turnStep,
        index: i + 1,
      }));
      const stepMeta = STEP_META[turnPhase]?.[turnStep - 1];
      phaseHint = stepMeta ? game.i18n.localize(stepMeta.hint) : "";
      isFirstPhase = turnPhase === "1" && turnStep === 1;
      isLastPhase = turnPhase === "3" && turnStep === 4;
    }

    const phase2stats = canRollConflicts
      ? this._computePhase2Stats(system)
      : null;
    const phase3data = isPhase3 ? this._computePhase3Data(system) : null;

    const hasEventTable = !!game.settings.get(MODULE_ID, "tableEvents");
    const isGM = game.user?.isGM ?? false;

    let generatedPois = [];
    if (turnPhase === "1" && turnStep === 1 && isGM) {
      generatedPois = await this._resolveGeneratedPois(
        system.turnGeneratedPois || [],
      );
    }

    // Phase 3 sub-step (1=POI outcomes, 2=Progression, 3=Reinforcements, 4=Summary)
    const phase3Step = isPhase3 ? turnStep : 1;
    if (isPhase3) {
      for (const col of poiColumns) {
        for (const entry of col.entries) {
          entry.phase3Step = phase3Step;
        }
      }
    }

    // Annotate assets with commandeered state for template display
    const commandeeredSet = new Set(system.commandeeredAssets || []);
    const allAssets = [...characterAssets, ...shipAssets, ...resourceAssets];
    const assetDocs = await Promise.all(allAssets.map((a) => fromUuid(a.uuid)));
    for (let i = 0; i < allAssets.length; i++) {
      const asset = allAssets[i];
      const doc = assetDocs[i];
      asset.isCommandeered = commandeeredSet.has(asset.uuid);
      // Read status directly from AE flags — more reliable than derived system fields
      asset.isUnavailable = !!doc?.effects?.some(
        (effect) => effect.active && effect.flags?.[MODULE_ID]?.unavailable,
      );
      asset.isLost = !!doc?.effects?.some(
        (effect) => effect.active && effect.flags?.[MODULE_ID]?.lost,
      );
    }

    // Build notification badge map for current-turn log entries
    const currentTurn = system.campaignTurnNumber || 0;
    const _badgeMap = {};
    for (const logEntry of system.notificationLog || []) {
      if (!logEntry.entityUuid || logEntry.turn !== currentTurn) continue;
      if (!_badgeMap[logEntry.entityUuid]) _badgeMap[logEntry.entityUuid] = [];
      _badgeMap[logEntry.entityUuid].push(logEntry);
    }
    const _badge = (uuid) => {
      const entries = _badgeMap[uuid] ?? [];
      return {
        hasBadge: entries.length > 0,
        count: entries.length,
        tooltip: entries.map((e) => e.message).join(" | "),
      };
    };
    for (const asset of allAssets) asset.badges = _badge(asset.uuid);
    for (const col of poiColumns) {
      for (const poiEntry of col.entries)
        poiEntry.poi.badges = _badge(poiEntry.poi.uuid);
    }

    return {
      actor,
      system,
      characterAssets,
      shipAssets,
      resourceAssets,
      poiColumns,
      turnActive,
      turnPhase,
      canGeneratePoi,
      canSelectScenario,
      canAssignAssets,
      canRollEvent,
      canRollConflicts,
      isPhase3,
      phaseSteps,
      subSteps,
      phaseHint,
      isFirstPhase,
      isLastPhase,
      generatedPois,
      generatedCount: generatedPois.length,
      paceSrc: system.pace || 0,
      generateAllLabel: game.i18n.format("STA_TC.Wizard.GenerateAllPois", {
        pace:
          (system.pace || 0) +
          (system.paceTempBonus || 0) +
          (system.turnExtraTacticalPoisNextTurn || 0) +
          (system.turnExtraUnknownPoisNextTurn || 0) +
          (system.turnExtraPoisNextTurn || 0),
      }),
      countLabel: game.i18n.format("STA_TC.Wizard.GeneratedCount", {
        current: generatedPois.length,
        pace:
          (system.pace || 0) +
          (system.paceTempBonus || 0) +
          (system.turnExtraTacticalPoisNextTurn || 0) +
          (system.turnExtraUnknownPoisNextTurn || 0) +
          (system.turnExtraPoisNextTurn || 0),
      }),
      isGM,
      hasEventTable,
      phase2stats,
      phase3data,
      phase3Step,
      commandeeredAssets: system.commandeeredAssets || [],
      turnNotes: system.turnNotes || "",
    };
  }

  // ==========================================================================
  // Helpers
  // ==========================================================================

  /**
   * Find or create a world Actor folder whose name matches this tracker.
   * @returns {Promise<Folder>}
   */
  async _getOrCreateTrackerFolder() {
    const name = this.actor.name;
    const existing = game.folders.find(
      (f) => f.type === "Actor" && f.name === name,
    );
    if (existing) return existing;
    return Folder.create({ name, type: "Actor", color: "#003399" });
  }

  /**
   * If the actor originates from a compendium, import a world copy and place
   * it in this tracker's folder.  Returns the actor unchanged when it is
   * already a world document.
   * @param {Actor} actor
   * @returns {Promise<Actor|null>}
   */
  async _importActorIfNeeded(actor) {
    if (!actor?.pack) return actor;
    const folder = await this._getOrCreateTrackerFolder();
    const data = actor.toObject();
    if (folder) data.folder = folder.id;
    return Actor.create(data);
  }

  async _getOrCreateSubfolder(parentFolder, subfolderName) {
    const existing = game.folders.find(
      (f) =>
        f.type === "Actor" &&
        f.name === subfolderName &&
        f.folder?.id === parentFolder.id,
    );
    if (existing) return existing;
    return Folder.create({
      name: subfolderName,
      type: "Actor",
      folder: parentFolder.id,
    });
  }

  async _getOrCreateAssetFolder(assetType) {
    const tracker = await this._getOrCreateTrackerFolder();
    const typeNameMap = {
      character: game.i18n.localize("STA_TC.Folders.Characters"),
      ship: game.i18n.localize("STA_TC.Folders.Ships"),
      resource: game.i18n.localize("STA_TC.Folders.Resources"),
    };
    const assetsFolder = await this._getOrCreateSubfolder(
      tracker,
      game.i18n.localize("STA_TC.Folders.Assets"),
    );
    return this._getOrCreateSubfolder(
      assetsFolder,
      typeNameMap[assetType] || typeNameMap.resource,
    );
  }

  async _getOrCreatePoiFolder(poiType) {
    const tracker = await this._getOrCreateTrackerFolder();
    const typeNameMap = {
      tacticalThreat: game.i18n.localize("STA_TC.Folders.TacticalThreats"),
      exploration: game.i18n.localize("STA_TC.Folders.Exploration"),
      routine: game.i18n.localize("STA_TC.Folders.Routine"),
      unknown: game.i18n.localize("STA_TC.Folders.Unknown"),
    };
    const poisFolder = await this._getOrCreateSubfolder(
      tracker,
      game.i18n.localize("STA_TC.Folders.PointsOfInterest"),
    );
    return this._getOrCreateSubfolder(
      poisFolder,
      typeNameMap[poiType] || typeNameMap.unknown,
    );
  }

  async _purgeStaleUuids() {
    // fromUuid can THROW (not just return null) when an actor was just deleted.
    const safeResolve = async (uuid) => {
      if (!uuid) return null;
      try {
        return await fromUuid(uuid);
      } catch {
        return null;
      }
    };

    const system = this.actor.system;
    const poiLists = [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ];
    const updates = {};

    for (const key of ["characterAssets", "shipAssets", "resourceAssets"]) {
      const list = system[key] || [];
      const valid = [];
      for (const uuid of list) {
        if (await safeResolve(uuid)) valid.push(uuid);
      }
      if (valid.length !== list.length) updates[`system.${key}`] = valid;
    }

    for (const listKey of poiLists) {
      const entries = foundry.utils.deepClone(system[listKey] || []);
      let changed = false;
      const cleaned = [];
      for (const entry of entries) {
        if (!(await safeResolve(entry.actorUuid))) {
          changed = true;
          continue;
        }
        if (entry.asset1Uuid && !(await safeResolve(entry.asset1Uuid))) {
          entry.asset1Uuid = "";
          changed = true;
        }
        if (entry.asset2Uuid && !(await safeResolve(entry.asset2Uuid))) {
          entry.asset2Uuid = "";
          changed = true;
        }
        cleaned.push(entry);
      }
      if (changed) updates[`system.${listKey}`] = cleaned;
    }

    const generated = system.turnGeneratedPois || [];
    const validGenerated = [];
    for (const uuid of generated) {
      if (await safeResolve(uuid)) validGenerated.push(uuid);
    }
    if (validGenerated.length !== generated.length)
      updates["system.turnGeneratedPois"] = validGenerated;

    if (system.scenarioPoi && !(await safeResolve(system.scenarioPoi))) {
      updates["system.scenarioPoi"] = "";
    }

    if (Object.keys(updates).length) await this.actor.update(updates);
  }

  async _buildAssetPoiMap(system) {
    const entries = [];
    for (const list of [
      system.poiListThreat,
      system.poiListExploration,
      system.poiListRoutine,
      system.poiListUnknown,
    ]) {
      for (const entry of list || []) {
        if (entry.asset1Uuid || entry.asset2Uuid) entries.push(entry);
      }
    }
    const pois = await Promise.all(entries.map((e) => fromUuid(e.actorUuid)));
    const map = {};
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i];
      const poiName = pois[i]?.name || "???";
      if (entry.asset1Uuid) map[entry.asset1Uuid] = poiName;
      if (entry.asset2Uuid) map[entry.asset2Uuid] = poiName;
    }
    return map;
  }

  static _isDefaultImg(img) {
    if (!img) return true;
    return /mystery-man/i.test(img) || img === CONST.DEFAULT_TOKEN;
  }

  static _nameInitials(name) {
    const words = (name || "").trim().split(/\s+/).filter(Boolean);
    if (!words.length) return "?";
    const first = words[0][0].toUpperCase();
    const second = words[1] ? words[1][0].toUpperCase() : "";
    return first + second;
  }

  async _resolveActorList(uuids, assetPoiMap = {}) {
    return (
      await Promise.all(
        (uuids || []).map(async (uuid) => {
          const actor = await fromUuid(uuid);
          if (!actor) return null;
          const powers = actor.system?.powers;
          const powerSummary = powers
            ? [
                { abbr: "Med", val: powers.medical?.value || 0 },
                { abbr: "Mil", val: powers.military?.value || 0 },
                { abbr: "Per", val: powers.personal?.value || 0 },
                { abbr: "Sci", val: powers.science?.value || 0 },
                { abbr: "Soc", val: powers.social?.value || 0 },
              ]
                .map((p) => `${p.abbr} ${p.val}`)
                .join(", ")
            : "";
          const useInitials = CampaignTrackerSheet._isDefaultImg(actor.img);
          return {
            uuid,
            name: actor.name,
            img: actor.img,
            initials: useInitials
              ? CampaignTrackerSheet._nameInitials(actor.name)
              : "",
            assetType: actor.system?.assetType || "resource",
            powerSummary,
            assignedTo: assetPoiMap[uuid] || null,
          };
        }),
      )
    ).filter(Boolean);
  }

  async _resolveAllPoiColumns(
    system,
    {
      canSelectScenario,
      canRollEvent,
      canRollConflicts,
      isPhase3,
      scenarioPoi,
    },
  ) {
    const cols = [
      {
        key: "poiListThreat",
        label: game.i18n.localize("STA_TC.CampaignTracker.PoiThreat"),
      },
      {
        key: "poiListExploration",
        label: game.i18n.localize("STA_TC.CampaignTracker.PoiExploration"),
      },
      {
        key: "poiListRoutine",
        label: game.i18n.localize("STA_TC.CampaignTracker.PoiRoutine"),
      },
      {
        key: "poiListUnknown",
        label: game.i18n.localize("STA_TC.CampaignTracker.PoiUnknown"),
      },
    ];
    const resultLabels = {
      success: "STA_TC.Wizard.ResultSuccess",
      flawedSuccess: "STA_TC.Wizard.ResultFlawedSuccess",
      failure: "STA_TC.Wizard.ResultFailure",
      seriousSetback: "STA_TC.Wizard.ResultSeriousSetback",
    };
    await Promise.all(
      cols.map(async (col) => {
        const entries = await this._resolvePoiList(system[col.key], col.key);
        for (const entry of entries) {
          const isScenario = entry.poi.uuid === scenarioPoi;
          entry.isScenario = isScenario;
          entry.canSelectScenario = canSelectScenario;
          entry.canRollEvent = canRollEvent;
          entry.canRollConflicts =
            canRollConflicts && !isScenario && !!(entry.asset1 || entry.asset2);
          entry.showConflictResult =
            entry.canRollConflicts ||
            (isPhase3 && !!entry.entryData.conflictResult);
          entry.hasEvent = !!entry.entryData.eventResult;
          entry.canResetEvent =
            entry.hasEvent && canRollEvent && (game.user?.isGM ?? false);
          entry.isConflictResolved = !!entry.entryData.conflictResult;
          // Advisory roll data: successes rolled but GM hasn't confirmed pass/fail yet
          if (
            !entry.isConflictResolved &&
            entry.entryData.conflictSuccesses > 0
          ) {
            entry.hasAdvisoryRoll = true;
            entry.advisorySuccesses = entry.entryData.conflictSuccesses;
            entry.advisoryHadNat20 = entry.entryData.conflictHadNat20 || false;
          }
          if (entry.isConflictResolved) {
            const cr = entry.entryData.conflictResult;
            entry.conflictResultLabel = game.i18n.localize(
              resultLabels[cr] || "",
            );
            entry.conflictMomentum = entry.entryData.conflictMomentum || 0;
            entry.conflictHadNat20 = entry.entryData.conflictHadNat20 || false;
            entry.needsConsequence =
              (cr === "flawedSuccess" || cr === "seriousSetback") &&
              !entry.entryData.consequenceChosen;
            entry.isSeriousSetback = cr === "seriousSetback";
            entry.isConflictFailure =
              cr === "failure" && !entry.entryData.failureChoice;
            const consequenceLabels = {
              extraPoi: "STA_TC.Wizard.ConsequenceExtraPoiChosen",
              rollLoss: "STA_TC.Wizard.ConsequenceRollLossChosen",
              increaseThreat: "STA_TC.Wizard.ConsequenceIncreaseThreatChosen",
            };
            const failureLabels = {
              withdraw: "STA_TC.Wizard.FailureWithdrawChosen",
              succeedAtCost: "STA_TC.Wizard.FailureSucceedAtCostChosen",
            };
            const rawConsequence = entry.entryData.consequenceChosen || "";
            entry.consequenceChosen = rawConsequence
              ? rawConsequence === "increaseThreat"
                ? game.i18n.format(
                    "STA_TC.Wizard.ConsequenceIncreaseThreatChosen",
                    {
                      amount: (entry.poi.difficulty || 1) * 2,
                    },
                  )
                : game.i18n.localize(
                    consequenceLabels[rawConsequence] || rawConsequence,
                  )
              : "";
            const rawFailure = entry.entryData.failureChoice || "";
            entry.failureChoice = rawFailure
              ? game.i18n.localize(failureLabels[rawFailure] || rawFailure)
              : "";
            entry.lossResult = entry.entryData.lossResult || "";
            entry.threatConsequenceLabel = game.i18n.format(
              "STA_TC.Wizard.ConsequenceIncreaseThreat",
              { amount: (entry.poi.difficulty || 1) * 2 },
            );
          }
          // Phase 3: per-entry outcome descriptor for the POI card Phase 3 slot
          if (isPhase3) {
            entry.outcomeConfirmed = entry.entryData.outcomeConfirmed || false;
            entry.outcomeIgnored = entry.entryData.outcomeIgnored || false;
            const isResolved =
              isScenario ||
              entry.entryData.conflictResult === "success" ||
              entry.entryData.conflictResult === "flawedSuccess";
            if (isResolved) {
              entry.phase3outcome = { type: "resolved" };
            } else {
              const { poiType, urgency = 1 } = entry.poi;
              if (poiType === "tacticalThreat") {
                const consequence =
                  urgency >= 3
                    ? "catastrophe"
                    : urgency === 2
                      ? "escalate"
                      : "intensify";
                entry.phase3outcome = {
                  type: "unresolvedThreat",
                  consequence,
                  showEscalationRoll: urgency >= 2,
                  escalationRolled: entry.entryData.escalationRolled || false,
                };
              } else if (poiType === "routine") {
                let commandeeredAssetName = "";
                const commandeeredUuid =
                  entry.entryData.commandeeredAssetUuid || "";
                if (commandeeredUuid) {
                  const asset = await fromUuid(commandeeredUuid);
                  commandeeredAssetName = asset?.name || "";
                }
                entry.phase3outcome = {
                  type: "unresolvedRoutine",
                  commandeeredAssetUuid: commandeeredUuid,
                  commandeeredAssetName,
                };
              } else if (poiType === "exploration") {
                entry.phase3outcome = {
                  type: "unresolvedExploration",
                  consequence:
                    entry.poi.missedCount >= 1
                      ? "remove"
                      : "difficultyIncrease",
                };
              } else {
                entry.phase3outcome = { type: "unresolvedUnknown" };
              }
            }
          }
        }
        col.entries = entries;
      }),
    );
    return cols;
  }

  async _resolvePoiList(entries, listKey) {
    return (
      await Promise.all(
        (entries || []).map(async (entry, index) => {
          const poi = await fromUuid(entry.actorUuid);
          if (!poi) return null;
          // Completely skip hidden POIs for non-GM users
          if (!game.user.isGM && poi.system?.hiddenByGM) return null;
          const asset1 = entry.asset1Uuid
            ? await fromUuid(entry.asset1Uuid)
            : null;
          const asset2 = entry.asset2Uuid
            ? await fromUuid(entry.asset2Uuid)
            : null;

          // Run complex-effect resolver with assigned assets for this PoI.
          const {
            poiOverrides,
            assetMods,
            descriptions,
            assetEffectDescriptions,
          } = EventEffectResolver.resolve(
            poi,
            [asset1, asset2].filter(Boolean),
          );
          // Helper: prefer overridden value, fall back to raw system field.
          const _ov = (key, fallback) =>
            poiOverrides[`system.${key}`] ?? fallback;

          const resolvedPower = _ov("power", poi.system?.power || "military");
          const resolvedPower2 = _ov("power2", poi.system?.power2 || "");

          return {
            listKey,
            index,
            entryData: entry,
            assetMods,
            poi: {
              uuid: entry.actorUuid,
              name: poi.name,
              displayName: (() => {
                if (poi.system?.revealed) {
                  // Revealed: show real name (realName for unknowns, actor name for others)
                  const isUnknown =
                    (poi.system?.poiType || "unknown") === "unknown";
                  return isUnknown && poi.system?.realName
                    ? poi.system.realName
                    : poi.name;
                }
                // Not revealed: show masked default name
                return poi.name;
              })(),
              showMasked: (() => {
                if (game.user.isGM) return false;
                return !poi.system?.revealed;
              })(),
              visibilityState: (() => {
                if (poi.system?.hiddenByGM) return "hidden";
                if (!poi.system?.revealed) return "masked";
                return "revealed";
              })(),
              img: poi.img,
              difficulty: _ov("difficulty", poi.system?.difficulty),
              urgency: _ov("urgency", poi.system?.urgency),
              isTacticalThreat: poi.system?.poiType === "tacticalThreat",
              poiType: poi.system?.poiType || "unknown",
              missedCount: poi.system?.missedCount || 0,
              power: resolvedPower,
              powerLabel: game.i18n.localize(
                `STA_TC.Powers.${this._capitalize(resolvedPower)}`,
              ),
              power2: resolvedPower2 || null,
              difficulty2: _ov("difficulty2", poi.system?.difficulty2) || null,
              powerLabel2: resolvedPower2
                ? game.i18n.localize(
                    `STA_TC.Powers.${this._capitalize(resolvedPower2)}`,
                  )
                : null,
              eventName: (() => {
                const eventItems =
                  poi.items?.filter((i) => i.type === `${MODULE_ID}.event`) ??
                  [];
                const latest = eventItems[eventItems.length - 1];
                return latest?.name || poi.system?.eventName || "";
              })(),
              eventDescription: (() => {
                const eventItems =
                  poi.items?.filter((i) => i.type === `${MODULE_ID}.event`) ??
                  [];
                const latest = eventItems[eventItems.length - 1];
                return (
                  latest?.system?.description ||
                  poi.system?.eventDescription ||
                  ""
                );
              })(),
              note: poi.system?.note || "",
              hasEventEffects:
                Object.keys(poiOverrides).length > 0 ||
                descriptions.length > 0 ||
                assetEffectDescriptions.length > 0 ||
                [...poi.items]
                  .filter((i) => i.type === `${MODULE_ID}.event`)
                  .some((item) =>
                    item.effects.some(
                      (e) => e.active && e.system.changes.length > 0,
                    ),
                  ),
              eventEffectTooltip:
                [...descriptions, ...assetEffectDescriptions].join("\n") ||
                null,
            },
            asset1: asset1
              ? {
                  uuid: entry.asset1Uuid,
                  name: asset1.name,
                  img: asset1.img,
                  note: asset1.system?.note || "",
                }
              : null,
            asset2: asset2
              ? {
                  uuid: entry.asset2Uuid,
                  name: asset2.name,
                  img: asset2.img,
                  note: asset2.system?.note || "",
                }
              : null,
          };
        }),
      )
    ).filter(Boolean);
  }

  async _resolveGeneratedPois(uuids) {
    return (
      await Promise.all(
        uuids.map(async (uuid) => {
          const actor = await fromUuid(uuid);
          if (!actor) return null;
          // Compute three-state visibility
          const visibilityState = actor.system?.hiddenByGM
            ? "hidden"
            : !actor.system?.revealed
              ? "masked"
              : "revealed";
          // Retrieve event result from tracker entry data
          const poiLists = [
            "poiListThreat",
            "poiListExploration",
            "poiListRoutine",
            "poiListUnknown",
          ];
          let eventResult = "";
          for (const lk of poiLists) {
            const e = (this.actor.system[lk] || []).find(
              (e) => e.actorUuid === uuid,
            );
            if (e?.eventResult) {
              eventResult = e.eventResult;
              break;
            }
          }
          return {
            uuid,
            name: actor.name,
            img: actor.img,
            poiType: actor.system?.poiType || "unknown",
            poiTypeLabel: game.i18n.localize(
              `STA_TC.Poi.Types.${this._capitalize(actor.system?.poiType || "unknown")}`,
            ),
            visibilityState,
            eventResult,
            difficulty: actor.system?.difficulty || 1,
            power: game.i18n.localize(
              `STA_TC.Powers.${this._capitalize(actor.system?.power || "military")}`,
            ),
            power2: actor.system?.power2
              ? game.i18n.localize(
                  `STA_TC.Powers.${this._capitalize(actor.system.power2)}`,
                )
              : null,
            difficulty2: actor.system?.difficulty2 || null,
          };
        }),
      )
    ).filter(Boolean);
  }

  async _computePhase2MomentumRows(system) {
    const resultLabels = {
      success: "STA_TC.Wizard.ResultSuccess",
      flawedSuccess: "STA_TC.Wizard.ResultFlawedSuccess",
      failure: "STA_TC.Wizard.ResultFailure",
      seriousSetback: "STA_TC.Wizard.ResultSeriousSetback",
    };
    const relevant = [];
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      for (const entry of system[listKey] || []) {
        if (!entry.asset1Uuid && !entry.asset2Uuid) continue;
        if (entry.actorUuid === system.scenarioPoi) continue;
        relevant.push(entry);
      }
    }
    const pois = await Promise.all(relevant.map((e) => fromUuid(e.actorUuid)));
    return relevant.map((entry, i) => {
      const name = pois[i]?.name ?? entry.actorUuid;
      const result = entry.conflictResult || "";
      return {
        name,
        result,
        resultLabel: result
          ? game.i18n.localize(resultLabels[result] || result)
          : "",
        successes: entry.conflictSuccesses || 0,
        momentum: entry.conflictMomentum || 0,
        resolved: !!result,
        isSuccess: result === "success" || result === "flawedSuccess",
        isFailure: result === "failure" || result === "seriousSetback",
      };
    });
  }

  _computePhase2Stats(system) {
    const poiLists = [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ];
    let total = 0,
      resolved = 0;
    for (const key of poiLists) {
      for (const entry of system[key] || []) {
        if (!entry.asset1Uuid && !entry.asset2Uuid) continue;
        if (entry.actorUuid === system.scenarioPoi) continue;
        total++;
        if (entry.conflictResult) resolved++;
      }
    }
    return {
      total,
      resolved,
      pending: total - resolved,
      allResolved: total > 0 && resolved === total,
      hasConflicts: total > 0,
      totalMomentum: system.turnMomentumGained || 0,
      threatIncrease: system.turnThreatIncrease || 0,
    };
  }

  _computePhase3Data(system) {
    const totalMomentum = system.turnMomentumGained || 0;
    const resolvedExplorationCount = (system.poiListExploration || []).filter(
      (e) =>
        e.conflictResult === "success" || e.conflictResult === "flawedSuccess",
    ).length;
    const fromExploration = resolvedExplorationCount * 3;
    const fromMomentum = system.turnMomentumSpent || 0;
    const roleplayBonus = system.turnRoleplayBonus || 0;
    const progressionGain = fromExploration + fromMomentum + roleplayBonus;
    const turnProgressionConfirmed = system.turnProgressionConfirmed || false;
    // When confirmed, the gain has already been written to system.progression —
    // use that value directly to avoid double-counting.
    const newProgressionTotal = turnProgressionConfirmed
      ? system.progression || 0
      : (system.progression || 0) + progressionGain;
    return {
      totalMomentum,
      threatIncrease: system.turnThreatIncrease || 0,
      extraPoisNextTurn: system.turnExtraPoisNextTurn || 0,
      progressionConfirmed: turnProgressionConfirmed,
      progressionBreakdown: {
        fromExploration,
        fromMomentum,
        roleplayBonus,
        total: progressionGain,
        currentProgression: system.progression || 0,
        newTotal: newProgressionTotal,
        rollsAvailable: Math.floor(newProgressionTotal / 5),
      },
      reinforcements: {
        needed: system.prioritySupply || 0,
        received: system.turnReinforcementsReceived || 0,
        remaining: Math.max(
          0,
          (system.prioritySupply || 0) -
            (system.turnReinforcementsReceived || 0),
        ),
      },
      hasEscalationTable: !!game.settings.get(MODULE_ID, "tableEscalation"),
      hasProgressionTable: true,
    };
  }

  // ==========================================================================
  // Drag & Drop
  // ==========================================================================

  /** @override */
  async _preRender(context, options) {
    await super._preRender(context, options);
    this._savedScrollPositions = {};
    for (const el of this.element?.querySelectorAll("[data-preserve-scroll]") ??
      []) {
      this._savedScrollPositions[el.dataset.preserveScroll] = el.scrollTop;
    }
  }

  /** @override */
  _onFirstRender(context, options) {
    super._onFirstRender?.(context, options);

    // Keyboard support: allow Enter/Space to activate anchor-based buttons
    this.element.addEventListener("keydown", (ev) => {
      if (ev.key !== "Enter" && ev.key !== " ") return;
      const target = ev.target;
      if (target.getAttribute("role") !== "button") return;
      ev.preventDefault();
      target.click();
    });
  }

  _onRender(context, options) {
    super._onRender(context, options);
    if (this._savedScrollPositions) {
      for (const el of this.element.querySelectorAll(
        "[data-preserve-scroll]",
      )) {
        const saved = this._savedScrollPositions[el.dataset.preserveScroll];
        if (saved !== undefined) el.scrollTop = saved;
      }
    }

    // Re-apply saved sidebar width and attach drag-to-resize handle
    const layoutEl = this.element.querySelector(".tracker-main-layout");
    if (layoutEl) {
      if (this._sidebarWidth) {
        layoutEl.style.setProperty("--sidebar-w", this._sidebarWidth + "px");
      }
      const handle = this.element.querySelector(".sidebar-resize-handle");
      if (handle) {
        const SIDEBAR_MIN = 58;
        const SIDEBAR_MAX = 230;
        handle.addEventListener("pointerdown", (e) => {
          e.preventDefault();
          handle.setPointerCapture(e.pointerId);
          handle.classList.add("is-dragging");
          let dragged = false;
          const onMove = (moveEvent) => {
            dragged = true;
            const rect = layoutEl.getBoundingClientRect();
            const newW = Math.min(
              SIDEBAR_MAX,
              Math.max(SIDEBAR_MIN, moveEvent.clientX - rect.left),
            );
            this._sidebarWidth = newW;
            layoutEl.style.setProperty("--sidebar-w", newW + "px");
          };
          const onUp = () => {
            handle.classList.remove("is-dragging");
            handle.removeEventListener("pointermove", onMove);
            handle.removeEventListener("pointerup", onUp);
            // Toggle on click (no drag movement detected)
            if (!dragged) {
              const current = this._sidebarWidth ?? SIDEBAR_MIN;
              const newW = current <= SIDEBAR_MIN ? SIDEBAR_MAX : SIDEBAR_MIN;
              this._sidebarWidth = newW;
              layoutEl.style.setProperty("--sidebar-w", newW + "px");
            }
          };
          handle.addEventListener("pointermove", onMove);
          handle.addEventListener("pointerup", onUp);
        });
      }
    }

    // Attach drag-to-canvas listeners for assets and POIs
    if (this.actor.isOwner) {
      for (const el of this.element.querySelectorAll(
        "[data-drag][data-uuid]",
      )) {
        el.setAttribute("draggable", "true");
        el.addEventListener("dragstart", (event) => {
          event.dataTransfer.setData(
            "text/plain",
            JSON.stringify({ type: "Actor", uuid: el.dataset.uuid }),
          );
          // Use just the portrait as the drag ghost so the hidden card-info
          // panel doesn't appear in the snapshot
          const portrait =
            el.querySelector(".asset-portrait-wrap") ??
            el.querySelector(".asset-thumb") ??
            el;
          event.dataTransfer.setDragImage(portrait, 24, 24);
        });
      }

      // Make filled POI assignment slots draggable so assets can be moved
      // between slots and POIs without having to unassign first.
      for (const wrapper of this.element.querySelectorAll(
        ".poi-slot-wrapper.filled[data-drag-context='poi-asset']",
      )) {
        wrapper.setAttribute("draggable", "true");
        wrapper.addEventListener("dragstart", (event) => {
          // Stop the event from bubbling to the parent .poi-entry so the
          // whole POI card doesn't get dragged instead.
          event.stopPropagation();
          event.dataTransfer.setData(
            "text/plain",
            JSON.stringify({
              type: "Actor",
              uuid: wrapper.dataset.uuid,
              sourceContext: "poi-asset",
              sourceKey: wrapper.dataset.sourceKey,
              sourceIndex: parseInt(wrapper.dataset.sourceIndex),
              sourceSlot: parseInt(wrapper.dataset.sourceSlot),
              sourceTrackerId: this.actor.id,
            }),
          );
          const thumb = wrapper.querySelector(".slot-thumb");
          if (thumb) event.dataTransfer.setDragImage(thumb, 16, 16);
        });
      }

      // Drag-over highlight for empty POI slots
      for (const slot of this.element.querySelectorAll(
        "[data-drop-target='poi-slot']",
      )) {
        slot.addEventListener("dragover", (e) => {
          e.preventDefault();
          slot.classList.add("drag-over");
        });
        slot.addEventListener("dragleave", () =>
          slot.classList.remove("drag-over"),
        );
        slot.addEventListener("drop", () => slot.classList.remove("drag-over"));
      }
    }

    // Attach POI column collapse/expand listeners (helper for re-attach after render)
    this._attachPoiColumnCollapseListeners();

    // Sidebar overflow indicator
    const sidebar = this.element.querySelector(".tracker-sidebar");
    const sidebarWrap = this.element.querySelector(".tracker-sidebar-wrap");
    if (sidebar && sidebarWrap) {
      const updateOverflow = () => {
        const hasMore =
          sidebar.scrollTop + sidebar.clientHeight < sidebar.scrollHeight - 4;
        sidebarWrap.classList.toggle("has-overflow-below", hasMore);
        sidebarWrap.classList.toggle(
          "has-overflow-above",
          sidebar.scrollTop > 4,
        );
      };
      sidebar.addEventListener("scroll", updateOverflow, { passive: true });
      // Run once after layout has settled
      requestAnimationFrame(updateOverflow);
    }
  }

  /**
   * Attach POI column collapse/expand listeners and restore state.
   * Call after every render to ensure toggling works after UI updates.
   */
  _attachPoiColumnCollapseListeners() {
    const collapseKey = `sta-tc.poi-col-collapsed.${this.actor.id}`;
    let collapsed;
    try {
      collapsed = JSON.parse(localStorage.getItem(collapseKey) ?? "{}");
    } catch {
      collapsed = {};
    }
    for (const col of this.element.querySelectorAll(".poi-column")) {
      const key = col.querySelector(".poi-column-toggle")?.dataset.colKey ?? "";
      if (collapsed[key]) col.classList.add("collapsed");
      else col.classList.remove("collapsed");
    }
    // Remove previous listeners to avoid stacking
    this.element.querySelectorAll(".poi-column-toggle").forEach((toggle) => {
      toggle.removeEventListener("click", toggle._collapseHandler);
      toggle._collapseHandler = (e) => {
        const col = toggle.closest(".poi-column");
        if (!col) return;
        const key = toggle.dataset.colKey ?? "";
        col.classList.toggle("collapsed");
        let state;
        try {
          state = JSON.parse(localStorage.getItem(collapseKey) ?? "{}");
        } catch {
          state = {};
        }
        state[key] = col.classList.contains("collapsed");
        localStorage.setItem(collapseKey, JSON.stringify(state));
      };
      toggle.addEventListener("click", toggle._collapseHandler);
    });
  }

  /** @override */
  async _onDrop(event) {
    let data;
    try {
      data = JSON.parse(event.dataTransfer.getData("text/plain"));
    } catch {
      return;
    }

    // Progression / Escalation items: save a copy into this tracker's log.
    if (data.type === "Item") {
      return this._handleDropProgressionItem(data);
    }

    if (data.type !== "Actor") return;
    let uuid = data.uuid;
    const target = event.target;

    // Resolve the actor type first so we can route correctly regardless of
    // where on the sheet the user dropped it.
    let actor = await fromUuid(uuid);
    if (!actor) return;

    // If the actor lives in a compendium, import it into the world first and
    // place it in this tracker's folder before adding it to the tracker.
    if (actor.pack) {
      actor = await this._importActorIfNeeded(actor);
      if (!actor) return;
      uuid = actor.uuid;
    }

    if (actor.type === `${MODULE_ID}.asset`) {
      // If dropped directly onto an empty POI slot, assign it there.
      const poiSlot = target.closest("[data-drop-target='poi-slot']");
      if (poiSlot) return this._handleDropPoiAsset(uuid, poiSlot, data);
      // Otherwise add to the sidebar asset strip (anywhere on the sheet).
      return this._handleDropAssetToSidebar(uuid, actor);
    }

    if (actor.type === `${MODULE_ID}.poi`) {
      const poiList = target.closest("[data-drop-target='poi']");
      return this._handleDropPoi(uuid, target, poiList, data);
    }
  }

  /**
   * Save a dropped Progression/Escalation item into this tracker's
   * Progression Log by creating an embedded copy (marked saved).
   * @param {{uuid: string}} data - Drag data for the dropped Item.
   */
  async _handleDropProgressionItem(data) {
    const item = await fromUuid(data.uuid);
    if (!item || item.type !== `${MODULE_ID}.progression`) return;
    const itemData = item.toObject();
    delete itemData._id;
    itemData.system = itemData.system || {};
    itemData.system.saved = true;
    await this.actor.createEmbeddedDocuments("Item", [itemData]);
    ui.notifications.info(
      game.i18n.format("STA_TC.Progression.SavedToLog", { name: item.name }),
    );
  }

  async _handleDropAssetToSidebar(uuid, actor) {
    const typeToKey = {
      character: "characterAssets",
      ship: "shipAssets",
      resource: "resourceAssets",
    };
    const listKey = typeToKey[actor.system?.assetType];
    if (!listKey) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.CampaignTracker.NotAnAsset"),
      );
      return;
    }
    const existing = this.actor.system[listKey] || [];
    if (existing.includes(uuid)) {
      ui.notifications.info(
        game.i18n.localize("STA_TC.CampaignTracker.AlreadyAdded"),
      );
      return;
    }
    await this.actor.update({ [`system.${listKey}`]: [...existing, uuid] });
  }

  _getPoiDropIndex(target) {
    const entry = target.closest(".poi-entry");
    if (entry?.dataset.sourceIndex !== undefined)
      return parseInt(entry.dataset.sourceIndex);
    return null;
  }

  static _poiTypeToListKey(actor, fallback) {
    return (
      {
        tacticalThreat: "poiListThreat",
        exploration: "poiListExploration",
        routine: "poiListRoutine",
        unknown: "poiListUnknown",
      }[actor.system?.poiType] || fallback
    );
  }

  async _handleDropPoi(uuid, dropTarget, poiListEl, data) {
    const actor = await fromUuid(uuid);
    if (!actor || actor.type !== `${MODULE_ID}.poi`) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.CampaignTracker.NotAPoi"),
      );
      return;
    }
    const targetListKey = CampaignTrackerSheet._poiTypeToListKey(
      actor,
      poiListEl?.dataset?.poiList || "poiListUnknown",
    );
    const isInternal = data.sourceTrackerId === this.actor.id;
    if (isInternal && data.sourceContext === "poi") {
      const sourceListKey = data.sourceKey;
      const fromIndex = data.sourceIndex;
      const dropIndex = this._getPoiDropIndex(dropTarget);
      if (sourceListKey === targetListKey) {
        const entries = foundry.utils.deepClone(
          this.actor.system[targetListKey] || [],
        );
        const resolvedDrop = dropIndex ?? entries.length - 1;
        if (fromIndex === resolvedDrop) return;
        const [moved] = entries.splice(fromIndex, 1);
        entries.splice(
          resolvedDrop > fromIndex ? resolvedDrop - 1 : resolvedDrop,
          0,
          moved,
        );
        await this.actor.update({ [`system.${targetListKey}`]: entries });
      } else {
        const sourceEntries = foundry.utils.deepClone(
          this.actor.system[sourceListKey] || [],
        );
        const targetEntries = foundry.utils.deepClone(
          this.actor.system[targetListKey] || [],
        );
        if (targetEntries.some((e) => e.actorUuid === uuid)) {
          ui.notifications.info(
            game.i18n.localize("STA_TC.CampaignTracker.AlreadyAdded"),
          );
          return;
        }
        const [moved] = sourceEntries.splice(fromIndex, 1);
        targetEntries.splice(dropIndex ?? targetEntries.length, 0, moved);
        await this.actor.update({
          [`system.${sourceListKey}`]: sourceEntries,
          [`system.${targetListKey}`]: targetEntries,
        });
      }
      return;
    }
    const entries = foundry.utils.deepClone(
      this.actor.system[targetListKey] || [],
    );
    if (entries.some((e) => e.actorUuid === uuid)) {
      ui.notifications.info(
        game.i18n.localize("STA_TC.CampaignTracker.AlreadyAdded"),
      );
      return;
    }
    entries.push({ actorUuid: uuid, asset1Uuid: "", asset2Uuid: "" });
    await this.actor.update({ [`system.${targetListKey}`]: entries });
  }

  async _handleDropPoiAsset(uuid, slotEl, data) {
    const actor = await fromUuid(uuid);
    if (!actor || actor.type !== `${MODULE_ID}.asset`) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.CampaignTracker.NotAnAsset"),
      );
      return;
    }
    const listKey = slotEl.dataset.poiList;
    const poiIndex = parseInt(slotEl.dataset.poiIndex);
    const slot = parseInt(slotEl.dataset.slot);
    const field = slot === 0 ? "asset1Uuid" : "asset2Uuid";
    const fromPoiSlot = data.sourceContext === "poi-asset";
    if (
      fromPoiSlot &&
      data.sourceKey === listKey &&
      data.sourceIndex === poiIndex &&
      data.sourceSlot === slot
    )
      return;
    if (!fromPoiSlot && this._isAssetAssignedToAnyPoi(uuid)) {
      const assetType = actor.system?.assetType;
      if (assetType === "resource") {
        const limit = this.actor.system.turnFlexibleDeployments ? 2 : 1;
        if (this._countResourceAssignments(uuid) >= limit) {
          ui.notifications.warn(
            game.i18n.format("STA_TC.Progression.AssetResourceLimitReached", {
              name: actor.name,
            }),
          );
          return;
        }
      } else {
        ui.notifications.warn(
          game.i18n.localize("STA_TC.CampaignTracker.AssetAlreadyAssigned"),
        );
        return;
      }
    }
    if (
      actor.effects?.some(
        (effect) => effect.active && effect.flags?.[MODULE_ID]?.unavailable,
      )
    ) {
      ui.notifications.warn(
        game.i18n.format("STA_TC.CampaignTracker.AssetUnavailableAssign", {
          name: actor.name,
        }),
      );
      return;
    }
    if (
      actor.effects?.some(
        (effect) => effect.active && effect.flags?.[MODULE_ID]?.lost,
      )
    ) {
      ui.notifications.warn(
        game.i18n.format("STA_TC.CampaignTracker.AssetLostAssign", {
          name: actor.name,
        }),
      );
      return;
    }
    if (slot === 0 && actor.system?.assetType === "resource") {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.Wizard.ResourceCannotBePrimary"),
      );
      return;
    }
    const updates = {};
    if (fromPoiSlot) {
      const srcEntries = foundry.utils.deepClone(
        this.actor.system[data.sourceKey] || [],
      );
      const srcField = data.sourceSlot === 0 ? "asset1Uuid" : "asset2Uuid";
      if (srcEntries[data.sourceIndex]) {
        srcEntries[data.sourceIndex][srcField] = "";
        updates[`system.${data.sourceKey}`] = srcEntries;
      }
    }
    const targetEntries = foundry.utils.deepClone(
      fromPoiSlot && data.sourceKey === listKey
        ? updates[`system.${listKey}`]
        : this.actor.system[listKey] || [],
    );
    if (!targetEntries[poiIndex]) return;
    targetEntries[poiIndex][field] = uuid;
    updates[`system.${listKey}`] = targetEntries;
    await this.actor.update(updates);
  }

  _isAssetAssignedToAnyPoi(uuid) {
    for (const list of [
      this.actor.system.poiListThreat,
      this.actor.system.poiListExploration,
      this.actor.system.poiListRoutine,
      this.actor.system.poiListUnknown,
    ]) {
      for (const entry of list || []) {
        if (entry.asset1Uuid === uuid || entry.asset2Uuid === uuid) return true;
      }
    }
    return false;
  }

  /** Count how many times a resource UUID appears in any assisting (slot 2) POI slot. */
  _countResourceAssignments(uuid) {
    let count = 0;
    for (const list of [
      this.actor.system.poiListThreat,
      this.actor.system.poiListExploration,
      this.actor.system.poiListRoutine,
      this.actor.system.poiListUnknown,
    ]) {
      for (const entry of list || []) {
        if (entry.asset1Uuid === uuid || entry.asset2Uuid === uuid) count++;
      }
    }
    return count;
  }

  // ==========================================================================
  // Action Handlers — Turn Lifecycle
  // ==========================================================================

  static async _onStartTurn(event, target) {
    const existing = this.actor.system.turnPhase;
    if (existing) {
      const userId = this.actor.system.turnUserId;
      if (userId && userId !== game.user.id) {
        const otherUser = game.users.get(userId);
        const override = await foundry.applications.api.DialogV2.confirm({
          window: { title: game.i18n.localize("STA_TC.Wizard.Title") },
          content: `<p>${game.i18n.format("STA_TC.Wizard.LockedBy", { user: otherUser?.name || "Unknown" })}</p>`,
          yes: { label: game.i18n.localize("STA_TC.Wizard.Override") },
          no: { label: game.i18n.localize("STA_TC.Cancel") },
        });
        if (!override) return;
        await this.actor.update({ "system.turnUserId": game.user.id });
      }
      return;
    }
    // Apply any supply bonus from the previous turn's progression results
    const supplyBonus = this.actor.system.nextTurnSupplyBonus || 0;
    const currentSupply = this.actor.system.prioritySupply || 0;

    await this.actor.update({
      "system.turnPhase": "1",
      "system.turnUserId": game.user.id,
      "system.scenarioPoi": "",
      "system.turnGeneratedPois": [],
      "system.turnThreatIncrease": 0,
      "system.turnRoleplayBonus": 0,
      "system.turnMomentumSpent": 0,
      "system.turnReinforcementsReceived": 0,
      "system.turnStep": 1,
      "system.turnFlexibleDeployments": false,
      "system.turnProgressionConfirmed": false,
      // Apply and clear the deferred supply bonus
      ...(supplyBonus > 0 && {
        "system.prioritySupply": currentSupply + supplyBonus,
        "system.nextTurnSupplyBonus": 0,
      }),
      // turnExtraTacticalPoisNextTurn and turnExtraUnknownPoisNextTurn are
      // intentionally NOT reset here — they carry over from _onEndTurn so
      // Phase 1 Step 1 knows the correct POI generation target.
      // Free any commandeered assets from the previous turn
      "system.commandeeredAssets": [],
    });
    if (supplyBonus > 0) {
      await TrackerNotifier.emit({
        tracker: this.actor,
        event: "supplyBonusApplied",
        message: game.i18n.format("STA_TC.Notify.SupplyBonusApplied", {
          amount: supplyBonus,
          total: currentSupply + supplyBonus,
        }),
      });
    }
  }

  static async _onCancelTurn(event, target) {
    const proceed = await foundry.applications.api.DialogV2.confirm({
      window: { title: game.i18n.localize("STA_TC.Wizard.Title") },
      content: `<p>${game.i18n.localize("STA_TC.Wizard.CancelConfirm")}</p>`,
    });
    if (!proceed) return;
    await this._clearTurnState();
  }

  static async _onNextPhase(event, target) {
    const system = this.actor.system;
    const turnPhase = system.turnPhase;
    const turnStep = system.turnStep || 1;
    const stepCount = STEP_COUNTS[turnPhase] || 1;

    // Validation: warn if hidden POIs exist when leaving Phase 1 Step 1
    if (turnPhase === "1" && turnStep === 1) {
      const generatedUuids = system.turnGeneratedPois || [];
      let hasHidden = false;
      for (const uuid of generatedUuids) {
        const poi = await fromUuid(uuid);
        if (poi?.system?.hiddenByGM) {
          hasHidden = true;
          break;
        }
      }
      if (hasHidden) {
        const proceed = await foundry.applications.api.DialogV2.confirm({
          window: { title: game.i18n.localize("STA_TC.Wizard.Title") },
          content: `<p>${game.i18n.localize("STA_TC.Poi.HiddenPoisWarning")}</p>`,
        });
        if (!proceed) return;
      }
    }

    // Validation: warn if no scenario selected when leaving Phase 1 Step 2
    if (turnPhase === "1" && turnStep === 2 && !system.scenarioPoi) {
      const proceed = await foundry.applications.api.DialogV2.confirm({
        window: { title: game.i18n.localize("STA_TC.Wizard.Title") },
        content: `<p>${game.i18n.localize("STA_TC.Wizard.NoScenarioWarning")}</p>`,
      });
      if (!proceed) return;
    }

    if (turnStep < stepCount) {
      // Advance sub-step within current phase
      const updates = { "system.turnStep": turnStep + 1 };
      // Consume carry-over extra POI counts when leaving the generation step
      if (turnPhase === "1" && turnStep === 1) {
        const carryTotal =
          (system.turnExtraTacticalPoisNextTurn || 0) +
          (system.turnExtraUnknownPoisNextTurn || 0) +
          (system.turnExtraPoisNextTurn || 0);
        if (carryTotal > 0) {
          await TrackerNotifier.emit({
            tracker: this.actor,
            event: "carryOverConsumed",
            message: game.i18n.format("STA_TC.Notify.CarryOverConsumed", {
              count: carryTotal,
            }),
          });
        }
        updates["system.turnExtraTacticalPoisNextTurn"] = 0;
        updates["system.turnExtraUnknownPoisNextTurn"] = 0;
        updates["system.turnExtraPoisNextTurn"] = 0;
      }
      await this.actor.update(updates);
    } else {
      // Advance to next phase
      const phaseIdx = PHASES.indexOf(turnPhase);
      if (phaseIdx >= PHASES.length - 1) return;
      const nextPhase = PHASES[phaseIdx + 1];
      const phaseUpdates = {
        "system.turnPhase": nextPhase,
        "system.turnStep": 1,
      };
      // On Phase 2 → Phase 3: promote pending notes to visible notes
      if (turnPhase === "2" && nextPhase === "3") {
        phaseUpdates["system.turnNotes"] = system.turnPendingNotes || "";
        phaseUpdates["system.turnPendingNotes"] = "";
      }
      await this.actor.update(phaseUpdates);
    }
  }

  static async _onPrevPhase(event, target) {
    const system = this.actor.system;
    const turnPhase = system.turnPhase;
    const turnStep = system.turnStep || 1;

    if (turnStep > 1) {
      await this.actor.update({ "system.turnStep": turnStep - 1 });
    } else {
      const phaseIdx = PHASES.indexOf(turnPhase);
      if (phaseIdx <= 0) return;
      const prevPhase = PHASES[phaseIdx - 1];
      const prevStepCount = STEP_COUNTS[prevPhase] || 1;
      await this.actor.update({
        "system.turnPhase": prevPhase,
        "system.turnStep": prevStepCount,
      });
    }
  }

  static async _onEndTurn(event, target) {
    // Begin batch notification window — all log writes are deferred until flushBatch()
    TrackerNotifier.beginBatch(this.actor);
    // Original snapshot — used for momentum total, roleplay bonus, and
    // resolvedExploration count (before we remove them from the list).
    const system = this.actor.system;
    const chatLines = [];

    // Capture within-turn extra-PoI consequences (flawed success → extra PoI) before
    // _clearTurnState() resets turnExtraPoisNextTurn.
    const extraPoisFromConsequences = system.turnExtraPoisNextTurn || 0;

    const scenarioPoi = system.scenarioPoi || "";
    const isResolved = (e) =>
      e.conflictResult === "success" ||
      e.conflictResult === "flawedSuccess" ||
      (!!scenarioPoi && e.actorUuid === scenarioPoi);

    // ---- VALIDATION: warn if any Phase 3 outcomes have not been confirmed ---
    const allEntries = [
      ...(system.poiListThreat || []),
      ...(system.poiListExploration || []),
      ...(system.poiListRoutine || []),
      ...(system.poiListUnknown || []),
    ];
    const unconfirmedCount = allEntries.filter(
      (e) => !isResolved(e) && !e.outcomeConfirmed && !e.outcomeIgnored,
    ).length;
    if (unconfirmedCount > 0) {
      const proceed = await foundry.applications.api.DialogV2.confirm({
        window: { title: game.i18n.localize("STA_TC.Wizard.Title") },
        content: `<p>${game.i18n.format("STA_TC.Wizard.OutcomesUnconfirmedWarning", { count: unconfirmedCount })}</p>`,
      });
      if (!proceed) return;
    }

    // Count resolved explorations BEFORE removal so we can award +3 each.
    const resolvedExplorationCount = (system.poiListExploration || []).filter(
      isResolved,
    ).length;

    // ---- A0: Apply event-driven asset unavailability AEs -------------------
    // Scan ALL POI entries (resolved + unresolved) before they are removed.
    // If the POI had an event rolled, check for asset_unavailable effects and
    // apply the corresponding Active Effects to assigned asset actors.
    const currentTurnNum = system.campaignTurnNumber || 0;
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      for (const entry of system[listKey] || []) {
        if (!entry.eventResult) continue; // no event was rolled this turn
        const poi = await fromUuid(entry.actorUuid);
        if (!poi) continue;
        const a1 = entry.asset1Uuid ? await fromUuid(entry.asset1Uuid) : null;
        const a2 = entry.asset2Uuid ? await fromUuid(entry.asset2Uuid) : null;
        const assets = [a1, a2].filter(Boolean);
        if (!assets.length) continue;
        const { unavailableAssets } = EventEffectResolver.resolve(poi, assets);
        for (const { actor, turns, label } of unavailableAssets) {
          const expireAfterTurn = currentTurnNum + turns;
          await this._applyUnavailableEffect(
            actor.uuid,
            label,
            expireAfterTurn,
          );
          chatLines.push(
            `<p>⏸ <strong>${actor.name}</strong>: ${game.i18n.format("STA_TC.Wizard.OutcomeAssetUnavailableEvent", { turns })} (${poi.name})</p>`,
          );
        }
      }
    }

    // ---- A: Remove successfully resolved POIs from all lists ----------------
    // Pre-collect actor documents for the optional deletion prompt.
    const resolvedActorUuids = [];
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      for (const entry of system[listKey] || []) {
        if (isResolved(entry) && entry.actorUuid)
          resolvedActorUuids.push(entry.actorUuid);
      }
    }
    const resolvedPoiActors = (
      await Promise.all(resolvedActorUuids.map((u) => fromUuid(u)))
    ).filter(Boolean);

    const removalUpdates = {};
    let resolvedCount = 0;
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      const entries = foundry.utils.deepClone(system[listKey] || []);
      const filtered = entries.filter((e) => {
        if (isResolved(e)) {
          resolvedCount++;
          return false;
        }
        return true;
      });
      removalUpdates[`system.${listKey}`] = filtered;
    }
    await this.actor.update(removalUpdates);
    if (resolvedCount)
      chatLines.push(
        `<p>&#x2705; ${game.i18n.format("STA_TC.Wizard.OutcomeResolved", { count: resolvedCount })}</p>`,
      );

    // ---- A2: Optionally delete the resolved POI actors ----------------------
    if (resolvedPoiActors.length) {
      const nameList = resolvedPoiActors
        .map((a) => `<li>${a.name}</li>`)
        .join("");
      const doDelete = await foundry.applications.api.DialogV2.confirm({
        window: { title: game.i18n.localize("STA_TC.Wizard.Title") },
        content: `<p>${game.i18n.localize("STA_TC.Wizard.DeleteResolvedPoiConfirm")}</p><ul style="margin:6px 0 0 16px">${nameList}</ul>`,
        yes: {
          label: game.i18n.localize("STA_TC.Wizard.DeleteResolvedPoiYes"),
          icon: "fas fa-trash",
        },
        no: { label: game.i18n.localize("STA_TC.Wizard.DeleteResolvedPoiNo") },
      });
      if (doDelete) {
        const actorIdSet = new Set(resolvedPoiActors.map((a) => a.id));
        const tokensToDelete = (
          canvas.scene?.tokens?.filter((t) => actorIdSet.has(t.actorId)) ?? []
        ).map((t) => t.id);
        if (tokensToDelete.length)
          await TokenDocument.deleteDocuments(tokensToDelete, {
            parent: canvas.scene,
          });
        await Actor.deleteDocuments(resolvedPoiActors.map((a) => a.id));
      }
    }

    // ---- B: Unresolved Tactical Threats ------------------------------------
    // Work from fresh system now that resolved POIs are removed.
    const sys2 = this.actor.system;
    let paceDelta = 0;
    let extraTacticalPois = 0;
    const finalThreatEntries = [];
    for (const entry of sys2.poiListThreat || []) {
      // Already handled by an outcome button — keep the entry as-is
      if (entry.outcomeConfirmed || entry.outcomeIgnored) {
        finalThreatEntries.push(entry);
        if (entry.outcomeConfirmed) {
          const confirmedPoi = await fromUuid(entry.actorUuid);
          chatLines.push(
            `<p>&#x1F53A; <strong>${confirmedPoi?.name || "?"}</strong>: ${game.i18n.localize("STA_TC.Wizard.OutcomeIntensify1Short")}</p>`,
          );
        }
        continue;
      }
      const poi = await fromUuid(entry.actorUuid);
      const urgency = poi?.system?.urgency || 1;
      if (urgency >= 3) {
        // Catastrophe: remove from play, increase pace, extra tactical POI next turn.
        paceDelta++;
        extraTacticalPois++;
        chatLines.push(
          `<p>&#x1F4A5; <strong>${poi?.name || "?"}</strong>: ${game.i18n.localize("STA_TC.Wizard.OutcomeCatastrophe")}</p>`,
        );
      } else {
        // Intensify: urgency++ and difficulty++ on the POI actor.
        const oldDiff = poi?.system?.difficulty || 1;
        if (poi) {
          const poiUpdates = {
            "system.urgency": Math.min(5, urgency + 1),
            "system.difficulty": Math.min(5, oldDiff + 1),
          };
          if (poi.system?.difficulty2 != null)
            poiUpdates["system.difficulty2"] = Math.min(
              5,
              poi.system.difficulty2 + 1,
            );
          await poi.update(poiUpdates);
        }
        finalThreatEntries.push(entry);
        const newUrgency = Math.min(5, urgency + 1);
        const newDiff = Math.min(5, oldDiff + 1);
        const intensifyDelta = ` <span style="opacity:0.75;font-size:0.9em;">(${game.i18n.localize("STA_TC.Poi.Urgency")} ${urgency}\u2192${newUrgency}, ${game.i18n.localize("STA_TC.Poi.Difficulty")} ${oldDiff}\u2192${newDiff})</span>`;
        chatLines.push(
          `<p>&#x1F53A; <strong>${poi?.name || "?"}</strong>: ${game.i18n.localize(urgency === 1 ? "STA_TC.Wizard.OutcomeIntensify1" : "STA_TC.Wizard.OutcomeIntensify2")}${intensifyDelta}</p>`,
        );
        await TrackerNotifier.emit({
          tracker: this.actor,
          event: "turnEndThreatIntensify",
          message: `${poi?.name || "?"}: ${game.i18n.localize(urgency === 1 ? "STA_TC.Wizard.OutcomeIntensify1" : "STA_TC.Wizard.OutcomeIntensify2")} (${game.i18n.localize("STA_TC.Poi.Urgency")} ${urgency}\u2192${newUrgency})`,
          entityUuid: entry.actorUuid,
        });
      }
    }
    const threatTrackerUpdates = { "system.poiListThreat": finalThreatEntries };
    if (paceDelta)
      threatTrackerUpdates["system.pace"] = (sys2.pace || 0) + paceDelta;
    await this.actor.update(threatTrackerUpdates);

    // ---- C: Unresolved Routine POIs ----------------------------------------
    const sys3 = this.actor.system;
    const newCommandeered = [...(sys3.commandeeredAssets || [])];
    let resourceAssets = [...(sys3.resourceAssets || [])];
    let assetListChanged = false;
    for (const entry of sys3.poiListRoutine || []) {
      // Ignored outcomes — this entry stays in the tracker, no commandeer applies
      if (entry.outcomeIgnored) continue;
      const uuid = entry.commandeeredAssetUuid;
      if (!uuid) continue;
      const asset = await fromUuid(uuid);
      if (asset?.system?.assetType === "resource") {
        // Resources are discarded immediately.
        resourceAssets = resourceAssets.filter((u) => u !== uuid);
        assetListChanged = true;
        chatLines.push(
          `<p>&#x1F4E6; <strong>${asset.name}</strong>: ${game.i18n.localize("STA_TC.Wizard.OutcomeResourceDiscarded")}</p>`,
        );
      } else if (asset) {
        // Character / Ship assets are commandeered until next turn.
        if (!newCommandeered.includes(uuid)) newCommandeered.push(uuid);
        assetListChanged = true;
        chatLines.push(
          `<p>&#x1F512; <strong>${asset.name}</strong>: ${game.i18n.localize("STA_TC.Wizard.OutcomeAssetCommandeered")}</p>`,
        );
        // Mark the actor with an unavailability AE so the status is visible
        // on the actor sheet and auto-expires at the next turn start.
        const expireAfterTurn = (sys3.campaignTurnNumber || 0) + 1;
        await this._applyUnavailableEffect(
          uuid,
          game.i18n.localize("STA_TC.Wizard.OutcomeAssetCommandeered"),
          expireAfterTurn,
        );
      }
    }
    if (assetListChanged)
      await this.actor.update({
        "system.commandeeredAssets": newCommandeered,
        "system.resourceAssets": resourceAssets,
      });

    // ---- D: Unresolved Exploration POIs ------------------------------------
    const sys4 = this.actor.system;
    const finalExplorationEntries = [];
    for (const entry of sys4.poiListExploration || []) {
      // Already handled by an outcome button — keep the entry as-is
      if (entry.outcomeConfirmed || entry.outcomeIgnored) {
        finalExplorationEntries.push(entry);
        if (entry.outcomeConfirmed) {
          const confirmedPoi = await fromUuid(entry.actorUuid);
          chatLines.push(
            `<p>&#x1F4CD; <strong>${confirmedPoi?.name || "?"}</strong>: ${game.i18n.localize("STA_TC.Wizard.OutcomeExplorationDiffShort")}</p>`,
          );
        }
        continue;
      }
      const poi = await fromUuid(entry.actorUuid);
      const missedCount = poi?.system?.missedCount || 0;
      if (missedCount >= 1) {
        // Second miss: remove from play.
        chatLines.push(
          `<p>&#x1F570;&#xFE0F; <strong>${poi?.name || "?"}</strong>: ${game.i18n.localize("STA_TC.Wizard.OutcomeExplorationRemoved")}</p>`,
        );
      } else {
        // First miss: difficulty++ and missedCount = 1 on the POI actor.
        const explorationOldDiff = poi?.system?.difficulty || 1;
        if (poi) {
          const poiUpdates = {
            "system.missedCount": 1,
            "system.difficulty": Math.min(5, explorationOldDiff + 1),
          };
          if (poi.system?.difficulty2 != null)
            poiUpdates["system.difficulty2"] = Math.min(
              5,
              poi.system.difficulty2 + 1,
            );
          await poi.update(poiUpdates);
        }
        finalExplorationEntries.push(entry);
        const explorationNewDiff = Math.min(5, explorationOldDiff + 1);
        const explorationDelta = ` <span style="opacity:0.75;font-size:0.9em;">(${game.i18n.localize("STA_TC.Poi.Difficulty")} ${explorationOldDiff}\u2192${explorationNewDiff})</span>`;
        chatLines.push(
          `<p>&#x1F4CD; <strong>${poi?.name || "?"}</strong>: ${game.i18n.localize("STA_TC.Wizard.OutcomeExplorationDifficultyIncrease")}${explorationDelta}</p>`,
        );
        await TrackerNotifier.emit({
          tracker: this.actor,
          event: "turnEndExplorationDiff",
          message: `${poi?.name || "?"}: ${game.i18n.localize("STA_TC.Wizard.OutcomeExplorationDifficultyIncrease")} (${game.i18n.localize("STA_TC.Poi.Difficulty")} ${explorationOldDiff}\u2192${explorationNewDiff})`,
          entityUuid: entry.actorUuid,
        });
      }
    }
    await this.actor.update({
      "system.poiListExploration": finalExplorationEntries,
    });

    // ---- E: Unresolved Unknown POIs ----------------------------------------
    const sys5 = this.actor.system;
    let extraUnknownPois = 0;
    const finalUnknownEntries = [];
    for (const entry of sys5.poiListUnknown || []) {
      if (entry.outcomeIgnored) {
        // Ignored — keep in list; counts as an extra PoI next turn since the
        // threat is still unresolved.
        finalUnknownEntries.push(entry);
        extraUnknownPois++;
        continue;
      }
      if (entry.outcomeConfirmed) {
        // Already applied via button — remove from list without counting again
        continue;
      }
      const poi = await fromUuid(entry.actorUuid);
      extraUnknownPois++;
      chatLines.push(
        `<p>&#x2753; <strong>${poi?.name || "?"}</strong>: ${game.i18n.localize("STA_TC.Wizard.OutcomeUnknownRemoved")}</p>`,
      );
    }
    if (
      extraUnknownPois ||
      finalUnknownEntries.length !== (sys5.poiListUnknown || []).length
    )
      await this.actor.update({ "system.poiListUnknown": finalUnknownEntries });

    // ---- F: Progression (exploration gains + momentum spend + GM roleplay bonus) ---
    const momentumSpent = system.turnMomentumSpent || 0;
    const progressionGain =
      resolvedExplorationCount * 3 +
      momentumSpent +
      (system.turnRoleplayBonus || 0);

    // ---- G: Apply progression gain -----------------------------------------
    const sys6 = this.actor.system;
    const finalUpdates = {};
    // Skip if progression was already confirmed and applied in Phase 3 Step 2
    const progressionAlreadyConfirmed =
      system.turnProgressionConfirmed || false;
    if (progressionGain > 0 && !progressionAlreadyConfirmed)
      finalUpdates["system.progression"] =
        (sys6.progression || 0) + progressionGain;
    if (momentumSpent > 0 && !progressionAlreadyConfirmed)
      finalUpdates["system.campaignMomentum"] = Math.max(
        0,
        (sys6.campaignMomentum || 0) - momentumSpent,
      );
    // Expire unavailability Active Effects whose expireAfterTurn has been reached.
    // Run BEFORE incrementing the turn counter so effects set to expire at turn N
    // are removed at the end of turn N (i.e. they lasted the full turn).
    const expiredEffects = await expireCampaignTurnEffects(this.actor);
    for (const { actor } of expiredEffects) {
      await TrackerNotifier.emit({
        tracker: this.actor,
        event: "turnEndAeExpired",
        message: game.i18n.format("STA_TC.Notify.AeExpired", {
          name: actor.name,
        }),
        entityUuid: actor.uuid,
      });
    }

    // Increment the campaign turn counter (used for AE expiry checks)
    finalUpdates["system.campaignTurnNumber"] =
      (sys6.campaignTurnNumber || 0) + 1;
    await this.actor.update(finalUpdates);

    // ---- Chat summary ------------------------------------------------------
    const totalMomentum = system.turnMomentumGained || 0;
    const extraPoisTotal =
      (system.turnExtraPoisNextTurn || 0) +
      extraTacticalPois +
      extraUnknownPois;
    await ChatMessage.create({
      content: `<div style="background:#333;border-radius:8px;padding:10px;color:#eee;">
        <h3 style="margin:0 0 8px;color:#ffd700;">&#x1F3C1; ${game.i18n.localize("STA_TC.Wizard.TurnComplete")}</h3>
        ${chatLines.join("")}
        ${totalMomentum > 0 ? `<p>${game.i18n.localize("STA_TC.Wizard.MomentumGained")}: <strong>+${totalMomentum}</strong></p>` : ""}
        ${sys6.turnThreatIncrease > 0 ? `<p>${game.i18n.localize("STA_TC.Wizard.ThreatIncrease")}: <strong>+${sys6.turnThreatIncrease}</strong></p>` : ""}
        ${progressionGain > 0 ? `<p>${game.i18n.localize("STA_TC.Wizard.ProgressionGained")}: <strong>+${progressionGain}</strong></p>` : ""}
        ${extraPoisTotal > 0 ? `<p>${game.i18n.localize("STA_TC.Wizard.ExtraPoisNextTurn")}: <strong>+${extraPoisTotal}</strong>${extraTacticalPois > 0 ? ` (${extraTacticalPois} tactical)` : ""}${extraUnknownPois > 0 ? ` (${extraUnknownPois} +difficulty)` : ""}</p>` : ""}
        ${paceDelta > 0 ? `<p>${game.i18n.localize("STA_TC.Wizard.PaceIncreased")}: <strong>+${paceDelta}</strong></p>` : ""}
      </div>`,
      speaker: { alias: game.i18n.localize("STA_TC.Wizard.SpeakerAlias") },
      whisper: [game.user.id],
    });
    await this._clearTurnState();

    // Persist carry-over extra PoI counts for the next turn's Phase 1 Step 1.
    // These survive until _onNextPhase consumes them when leaving that step.
    const carryOver = {
      "system.turnExtraTacticalPoisNextTurn": extraTacticalPois,
      "system.turnExtraUnknownPoisNextTurn": extraUnknownPois,
      "system.turnExtraPoisNextTurn": extraPoisFromConsequences,
    };
    if (extraTacticalPois || extraUnknownPois || extraPoisFromConsequences)
      await this.actor.update(carryOver);
    // Flush accumulated notification log entries in one batch write
    await TrackerNotifier.flushBatch();
  }

  async _clearTurnState() {
    const system = this.actor.system;
    const updates = {
      "system.turnPhase": "",
      "system.turnUserId": "",
      "system.scenarioPoi": "",
      "system.turnGeneratedPois": [],
      "system.turnThreatIncrease": 0,
      "system.turnExtraPoisNextTurn": 0,
      "system.paceTempBonus": 0,
      "system.turnMomentumGained": 0,
      "system.turnRoleplayBonus": 0,
      "system.turnMomentumSpent": 0,
      "system.turnReinforcementsReceived": 0,
      "system.turnExtraTacticalPoisNextTurn": 0,
      "system.turnExtraUnknownPoisNextTurn": 0,
      "system.turnStep": 1,
      "system.turnFlexibleDeployments": false,
      "system.nextTurnSupplyBonus": 0,
      "system.turnProgressionConfirmed": false,
      // commandeeredAssets intentionally NOT cleared here — they persist until
      // the next turn starts so the badge remains visible between turns.
      "system.turnPendingNotes": "",
    };
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      const entries = foundry.utils.deepClone(system[listKey] || []);
      for (const entry of entries) {
        entry.eventResult = "";
        entry.conflictResult = "";
        entry.conflictSuccesses = 0;
        entry.conflictMomentum = 0;
        entry.conflictHadNat20 = false;
        entry.consequenceChosen = "";
        entry.failureChoice = "";
        entry.lossResult = "";
        entry.escalationRolled = false;
        entry.commandeeredAssetUuid = "";
        entry.outcomeConfirmed = false;
        entry.outcomeIgnored = false;
        entry.asset1Uuid = "";
        entry.asset2Uuid = "";
      }
      updates[`system.${listKey}`] = entries;
    }
    await this.actor.update(updates);
  }

  // ==========================================================================
  // Action Handlers — Asset Management
  // ==========================================================================

  /**
   * Show a dialog asking whether to also delete the world actor.
   * Returns true (delete actor too), false (remove from tracker only),
   * or null (cancelled).
   */
  static async _confirmRemove(actorName) {
    return foundry.applications.api.DialogV2.wait({
      window: {
        title: game.i18n.localize("STA_TC.CampaignTracker.RemoveTitle"),
      },
      content: `<p>${game.i18n.format("STA_TC.CampaignTracker.RemovePrompt", { name: actorName })}</p>`,
      buttons: [
        {
          action: "delete",
          label: game.i18n.localize("STA_TC.CampaignTracker.RemoveAndDelete"),
          icon: "fas fa-trash",
          default: false,
          callback: () => true,
        },
        {
          action: "remove",
          label: game.i18n.localize("STA_TC.CampaignTracker.RemoveOnly"),
          icon: "fas fa-times",
          default: true,
          callback: () => false,
        },
      ],
      rejectClose: false,
    });
  }

  static async _onRemoveAsset(event, target) {
    const keyMap = {
      character: "characterAssets",
      ship: "shipAssets",
      resource: "resourceAssets",
    };
    const key = keyMap[target.dataset.assetType];
    const list = [...(this.actor.system[key] || [])];
    const uuid = list[parseInt(target.dataset.index)];
    const actor = uuid ? await fromUuid(uuid) : null;
    const deleteActor = await CampaignTrackerSheet._confirmRemove(
      actor?.name ?? "",
    );
    if (deleteActor === null) return;
    list.splice(parseInt(target.dataset.index), 1);
    await this.actor.update({ [`system.${key}`]: list });
    if (deleteActor && actor) await actor.delete();
  }

  static async _onOpenActor(event, target) {
    const actor = await fromUuid(target.dataset.uuid);
    if (actor) actor.sheet.render(true);
  }

  static async _onCreateRandomAsset(event, target) {
    // Roll 1d20 to determine asset type per the campaign rules:
    // 1–5: Resource, 6–10: Ship, 11–15: Character if ≤2 Character assets else Ship, 16–20: Character
    const roll = await new Roll("1d20").evaluate();
    let typeChoice;
    if (roll.total <= 5) {
      typeChoice = "resource";
    } else if (roll.total <= 10) {
      typeChoice = "ship";
    } else if (roll.total <= 15) {
      const characterCount = (this.actor.system.characterAssets || []).length;
      typeChoice = characterCount <= 2 ? "character" : "ship";
    } else {
      typeChoice = "character";
    }

    const result = await AssetGenerator.generateForType(typeChoice);
    if (!result?.actor) return;
    // Import the actor into the world (tracker's folder) if it came from a compendium.
    const actor = await this._importActorIfNeeded(result.actor);
    if (!actor) return;
    const assetTypeFolder = await this._getOrCreateAssetFolder(typeChoice);
    if (assetTypeFolder) await actor.update({ folder: assetTypeFolder.id });
    const keyMap = {
      character: "characterAssets",
      ship: "shipAssets",
      resource: "resourceAssets",
    };
    const key = keyMap[actor.system?.assetType || "resource"];
    const list = [...(this.actor.system[key] || [])];
    if (!list.includes(actor.uuid)) {
      list.push(actor.uuid);
      const updates = { [`system.${key}`]: list };
      if (this.actor.system.turnPhase === "3")
        updates["system.turnReinforcementsReceived"] =
          (this.actor.system.turnReinforcementsReceived || 0) + 1;
      await this.actor.update(updates);
    }
  }

  static async _onCreateCustomAsset(event, target) {
    const actor = await Actor.create({
      name: game.i18n.localize("STA_TC.AssetName"),
      type: `${MODULE_ID}.asset`,
    });
    if (!actor) return;
    actor.sheet.render(true);
    const list = [...(this.actor.system.resourceAssets || [])];
    if (!list.includes(actor.uuid)) {
      list.push(actor.uuid);
      const updates = { "system.resourceAssets": list };
      if (this.actor.system.turnPhase === "3")
        updates["system.turnReinforcementsReceived"] =
          (this.actor.system.turnReinforcementsReceived || 0) + 1;
      await this.actor.update(updates);
    }
  }

  static async _onCreateAssetForType(event, target) {
    const assetType = target.dataset.assetType;
    const typeName = game.i18n.localize(
      `STA_TC.Asset.Generator.Types.${assetType.charAt(0).toUpperCase() + assetType.slice(1)}`,
    );
    const choice = await foundry.applications.api.DialogV2.wait({
      window: {
        title: game.i18n.format("STA_TC.CampaignTracker.AddAsset", {
          type: typeName,
        }),
      },
      content: `<p>${game.i18n.format("STA_TC.CampaignTracker.AddAsset", { type: typeName })}</p>`,
      buttons: [
        {
          action: "random",
          label: game.i18n.localize("STA_TC.CampaignTracker.CreateRandomAsset"),
          icon: "fas fa-random",
          default: true,
          callback: () => "random",
        },
        {
          action: "custom",
          label: game.i18n.localize("STA_TC.CampaignTracker.CreateCustomAsset"),
          icon: "fas fa-plus",
          default: false,
          callback: () => "custom",
        },
      ],
      rejectClose: false,
    });
    if (!choice) return;

    const keyMap = {
      character: "characterAssets",
      ship: "shipAssets",
      resource: "resourceAssets",
    };
    const key = keyMap[assetType] ?? "resourceAssets";

    if (choice === "random") {
      const result = await AssetGenerator.generateForType(assetType);
      if (!result?.actor) return;
      const actor = await this._importActorIfNeeded(result.actor);
      if (!actor) return;
      const assetTypeFolder = await this._getOrCreateAssetFolder(assetType);
      if (assetTypeFolder) await actor.update({ folder: assetTypeFolder.id });
      const list = [...(this.actor.system[key] || [])];
      if (!list.includes(actor.uuid)) {
        list.push(actor.uuid);
        const updates = { [`system.${key}`]: list };
        if (this.actor.system.turnPhase === "3")
          updates["system.turnReinforcementsReceived"] =
            (this.actor.system.turnReinforcementsReceived || 0) + 1;
        await this.actor.update(updates);
      }
    } else {
      const actor = await Actor.create({
        name: game.i18n.localize("STA_TC.AssetName"),
        type: `${MODULE_ID}.asset`,
        system: { assetType },
      });
      if (!actor) return;
      actor.sheet.render(true);
      const list = [...(this.actor.system[key] || [])];
      if (!list.includes(actor.uuid)) {
        list.push(actor.uuid);
        const updates = { [`system.${key}`]: list };
        if (this.actor.system.turnPhase === "3")
          updates["system.turnReinforcementsReceived"] =
            (this.actor.system.turnReinforcementsReceived || 0) + 1;
        await this.actor.update(updates);
      }
    }
  }

  // ==========================================================================
  // Action Handlers — POI Management
  // ==========================================================================

  static async _onRemovePoi(event, target) {
    const listKey = target.dataset.poiList;
    const entries = [...(this.actor.system[listKey] || [])];
    const uuid = entries[parseInt(target.dataset.index)]?.actorUuid;
    const actor = uuid ? await fromUuid(uuid) : null;
    const deleteActor = await CampaignTrackerSheet._confirmRemove(
      actor?.name ?? "",
    );
    if (deleteActor === null) return;
    entries.splice(parseInt(target.dataset.index), 1);
    await this.actor.update({ [`system.${listKey}`]: entries });
    if (deleteActor && actor) await actor.delete();
  }

  static async _onRemovePoiAsset(event, target) {
    event.stopPropagation();
    const listKey = target.dataset.poiList;
    const poiIndex = parseInt(target.dataset.poiIndex);
    const field =
      parseInt(target.dataset.slot) === 0 ? "asset1Uuid" : "asset2Uuid";
    const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
    if (!entries[poiIndex]) return;
    entries[poiIndex][field] = "";
    await this.actor.update({ [`system.${listKey}`]: entries });
  }

  static async _onRecallAsset(event, target) {
    const uuid = target.dataset.uuid;
    if (!uuid) return;
    const lists = [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ];
    const updates = {};
    for (const listKey of lists) {
      const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
      let changed = false;
      for (const entry of entries) {
        if (entry.asset1Uuid === uuid) {
          entry.asset1Uuid = "";
          changed = true;
        }
        if (entry.asset2Uuid === uuid) {
          entry.asset2Uuid = "";
          changed = true;
        }
      }
      if (changed) updates[`system.${listKey}`] = entries;
    }
    if (Object.keys(updates).length) await this.actor.update(updates);
  }

  static async _onAssignAsset(event, target) {
    const listKey = target.dataset.poiList;
    const poiIndex = parseInt(target.dataset.poiIndex);
    const slot = parseInt(target.dataset.slot);
    const field = slot === 0 ? "asset1Uuid" : "asset2Uuid";

    const system = this.actor.system;
    const allUuids = [
      ...(system.characterAssets || []),
      ...(system.shipAssets || []),
      ...(system.resourceAssets || []),
    ];

    const available = [];
    for (const uuid of allUuids) {
      if (!this._isAssetAssignedToAnyPoi(uuid)) {
        const actor = await fromUuid(uuid);
        if (
          actor &&
          !actor.effects?.some(
            (effect) => effect.active && effect.flags?.[MODULE_ID]?.unavailable,
          ) &&
          !actor.effects?.some(
            (effect) => effect.active && effect.flags?.[MODULE_ID]?.lost,
          ) &&
          !(slot === 0 && actor.system?.assetType === "resource")
        ) {
          const powers = actor.system?.powers;
          const stats = powers
            ? [
                { abbr: "Mil", val: powers.military?.value || 0 },
                { abbr: "Med", val: powers.medical?.value || 0 },
                { abbr: "Per", val: powers.personal?.value || 0 },
                { abbr: "Sci", val: powers.science?.value || 0 },
                { abbr: "Soc", val: powers.social?.value || 0 },
              ]
                .filter((p) => p.val > 0)
                .map((p) => `${p.abbr} ${p.val}`)
                .join(", ")
            : "";
          available.push({ uuid, name: actor.name, img: actor.img, stats });
        }
      } else {
        // For resource assets with Flexible Deployments, allow a second assignment
        const actor = await fromUuid(uuid);
        if (
          actor &&
          actor.system?.assetType === "resource" &&
          slot !== 0 &&
          !actor.effects?.some(
            (effect) => effect.active && effect.flags?.[MODULE_ID]?.unavailable,
          ) &&
          !actor.effects?.some(
            (effect) => effect.active && effect.flags?.[MODULE_ID]?.lost,
          )
        ) {
          const limit = this.actor.system.turnFlexibleDeployments ? 2 : 1;
          if (this._countResourceAssignments(uuid) < limit) {
            const powers = actor.system?.powers;
            const stats = powers
              ? [
                  { abbr: "Mil", val: powers.military?.value || 0 },
                  { abbr: "Med", val: powers.medical?.value || 0 },
                  { abbr: "Per", val: powers.personal?.value || 0 },
                  { abbr: "Sci", val: powers.science?.value || 0 },
                  { abbr: "Soc", val: powers.social?.value || 0 },
                ]
                  .filter((p) => p.val > 0)
                  .map((p) => `${p.abbr} ${p.val}`)
                  .join(", ")
              : "";
            available.push({ uuid, name: actor.name, img: actor.img, stats });
          }
        }
      }
    }

    if (!available.length) {
      ui.notifications.info(
        game.i18n.localize("STA_TC.CampaignTracker.NoUnassignedAssets"),
      );
      return;
    }

    const rows = available
      .map(
        (a, i) =>
          `<label class="asset-picker-row">
        <input type="radio" name="assetUuid" value="${a.uuid}" ${i === 0 ? "checked" : ""} />
        <img src="${a.img}" width="26" height="26" style="border-radius:3px;object-fit:cover;flex-shrink:0;" />
        <div class="asset-picker-info">
          <span class="asset-picker-name">${a.name}</span>
          ${a.stats ? `<span class="asset-picker-stats">${a.stats}</span>` : ""}
        </div>
      </label>`,
      )
      .join("");

    const uuid = await foundry.applications.api.DialogV2.prompt({
      window: {
        title: game.i18n.localize("STA_TC.CampaignTracker.AssignAsset"),
      },
      content: `<div class="asset-picker-list">${rows}</div>`,
      ok: {
        label: game.i18n.localize("STA_TC.CampaignTracker.Assign"),
        callback: (_ev, button) => button.form.elements.assetUuid.value || null,
      },
      rejectClose: false,
    });

    if (!uuid) return;
    const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
    if (!entries[poiIndex]) return;
    entries[poiIndex][field] = uuid;
    await this.actor.update({ [`system.${listKey}`]: entries });
  }

  static async _onGeneratePoi(event, target) {
    const result = await PoiGenerator.generate();
    if (!result?.actor) return;

    await RollTableManagerService.ensureTrackerQueues(this.actor);

    const actor = result.actor;
    const folder = await this._getOrCreatePoiFolder(
      actor.system?.poiType || "unknown",
    );
    // Start hidden so the GM can prep before revealing to players
    await actor.update({
      folder: folder?.id ?? null,
      "system.hiddenByGM": true,
    });
    const uuid = actor.uuid;
    const listKey = CampaignTrackerSheet._poiTypeToListKey(
      actor,
      "poiListUnknown",
    );
    const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
    if (!entries.some((e) => e.actorUuid === uuid))
      entries.push({ actorUuid: uuid, asset1Uuid: "", asset2Uuid: "" });
    const generated = [...(this.actor.system.turnGeneratedPois || []), uuid];
    await this.actor.update({
      [`system.${listKey}`]: entries,
      "system.turnGeneratedPois": generated,
    });

    const sourceActorUuid = result?.subResult?.documentUuid || "";
    if (sourceActorUuid && result?.subTableKey) {
      try {
        await RollTableManagerService.drawTimeMoveResultToUsed({
          tracker: this.actor,
          subKey: result.subTableKey,
          sourceActorUuid,
        });
      } catch (error) {
        console.warn(
          `${MODULE_ID} | Could not move generated POI result to used queue`,
          error,
        );
      }
    }
  }

  static async _onCreateCustomPoi(event, target) {
    const folder = await this._getOrCreatePoiFolder("unknown");
    const actor = await Actor.create({
      name: game.i18n.localize("STA_TC.PoiName"),
      type: `${MODULE_ID}.poi`,
      folder: folder?.id ?? null,
      "system.hiddenByGM": true,
    });
    if (!actor) return;
    actor.sheet.render(true);
    const uuid = actor.uuid;
    const listKey = CampaignTrackerSheet._poiTypeToListKey(
      actor,
      "poiListUnknown",
    );
    const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
    if (!entries.some((e) => e.actorUuid === uuid))
      entries.push({ actorUuid: uuid, asset1Uuid: "", asset2Uuid: "" });
    const generated = [...(this.actor.system.turnGeneratedPois || []), uuid];
    await this.actor.update({
      [`system.${listKey}`]: entries,
      "system.turnGeneratedPois": generated,
    });
  }

  static async _onGenerateAllPois(event, target) {
    await RollTableManagerService.ensureTrackerQueues(this.actor);

    const system = this.actor.system;
    const pace =
      (system.pace || 0) +
      (system.paceTempBonus || 0) +
      (system.turnExtraTacticalPoisNextTurn || 0) +
      (system.turnExtraUnknownPoisNextTurn || 0) +
      (system.turnExtraPoisNextTurn || 0);
    if (pace <= 0) {
      ui.notifications.warn(game.i18n.localize("STA_TC.Wizard.PaceIsZero"));
      return;
    }
    const batchRows = [];
    for (let i = 0; i < pace; i++) {
      const result = await PoiGenerator.generate({ postChat: false });
      if (!result?.actor) {
        batchRows.push({
          actor: null,
          subTableKey: result?.subTableKey ?? null,
          status: result?.status ?? "failed",
        });
        continue;
      }
      const actor = await this._importActorIfNeeded(result.actor);
      if (!actor) {
        batchRows.push({
          actor: null,
          subTableKey: result.subTableKey,
          status: "importFailed",
        });
        continue;
      }
      const poiFolder = await this._getOrCreatePoiFolder(
        actor.system?.poiType || "unknown",
      );
      // Start hidden so the GM can prep before revealing to players
      await actor.update({
        folder: poiFolder?.id ?? null,
        "system.hiddenByGM": true,
      });
      batchRows.push({ actor, subTableKey: result.subTableKey, status: "ok" });
      const uuid = actor.uuid;
      const listKey = CampaignTrackerSheet._poiTypeToListKey(
        actor,
        "poiListUnknown",
      );
      // Re-read system each iteration to get the latest state
      const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
      if (!entries.some((e) => e.actorUuid === uuid))
        entries.push({ actorUuid: uuid, asset1Uuid: "", asset2Uuid: "" });
      const generated = [...(this.actor.system.turnGeneratedPois || []), uuid];
      await this.actor.update({
        [`system.${listKey}`]: entries,
        "system.turnGeneratedPois": generated,
      });

      const sourceActorUuid = result?.subResult?.documentUuid || "";
      if (sourceActorUuid && result?.subTableKey) {
        try {
          await RollTableManagerService.drawTimeMoveResultToUsed({
            tracker: this.actor,
            subKey: result.subTableKey,
            sourceActorUuid,
          });
        } catch (error) {
          console.warn(
            `${MODULE_ID} | Could not move generated POI result to used queue`,
            error,
          );
        }
      }
    }
    // Post one consolidated chat card for all generated POIs
    if (batchRows.length) {
      await ChatMessage.create({
        content: PoiGenerator.buildBatchChatHtml(batchRows),
        speaker: {
          alias: game.i18n.localize("STA_TC.Poi.Generator.SpeakerAlias"),
        },
        whisper: [game.user.id],
      });
    }
  }

  static async _onOpenRollTableManager(event, target) {
    if (!game.user.isGM) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.RollTableManager.Errors.GmOnly"),
      );
      return;
    }
    RollTableManager.open(this.actor);
  }

  static async _onRemoveGeneratedPoi(event, target) {
    const uuid = target.dataset.uuid;
    if (!uuid) return;
    const actor = await fromUuid(uuid);
    const deleteActor = await CampaignTrackerSheet._confirmRemove(
      actor?.name ?? "",
    );
    if (deleteActor === null) return;
    const generated = (this.actor.system.turnGeneratedPois || []).filter(
      (u) => u !== uuid,
    );
    const updates = { "system.turnGeneratedPois": generated };
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      const filtered = (this.actor.system[listKey] || []).filter(
        (e) => e.actorUuid !== uuid,
      );
      if (filtered.length !== (this.actor.system[listKey] || []).length)
        updates[`system.${listKey}`] = filtered;
    }
    await this.actor.update(updates);
    if (deleteActor && actor) await actor.delete();
  }

  static async _onSelectScenario(event, target) {
    const uuid = target.dataset.uuid;
    if (!uuid) return;
    await this.actor.update({
      "system.scenarioPoi": this.actor.system.scenarioPoi === uuid ? "" : uuid,
    });
  }

  // ==========================================================================
  // Action Handlers — Events (Phase 1c)
  // ==========================================================================

  static async _onRollEvent(event, target) {
    const uuid = target.dataset.uuid;
    if (!uuid) return;
    const poi = await fromUuid(uuid);
    await this._rollEventForPoi(uuid);
    const listKey = [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]
      .flatMap((k) => this.actor.system[k] || [])
      .find((e) => e.actorUuid === uuid);
    const resultName = listKey?.eventResult || "";
    if (resultName)
      ui.notifications.info(`${poi?.name || "POI"}: ${resultName}`);
  }

  static async _onResetEvent(event, target) {
    // GM-only safeguard, even if someone injects the button client-side.
    if (!game.user?.isGM) return;
    const poiUuid = target.dataset.uuid;
    if (!poiUuid) return;

    const poi = await fromUuid(poiUuid);
    if (poi) {
      const eventIds = poi.items
        .filter((i) => i.type === `${MODULE_ID}.event`)
        .map((i) => i.id);
      if (eventIds.length) await poi.deleteEmbeddedDocuments("Item", eventIds);
    }

    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
      const idx = entries.findIndex((e) => e.actorUuid === poiUuid);
      if (idx !== -1) {
        entries[idx].eventResult = "";
        await this.actor.update({ [`system.${listKey}`]: entries });
        break;
      }
    }
  }

  static async _onRollRandomEvent(event, target) {
    if (!game.settings.get(MODULE_ID, "tableEvents")) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.Wizard.EventTableNotConfigured"),
      );
      return;
    }
    const scenarioPoi = this.actor.system.scenarioPoi || "";
    const allUuids = [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]
      .flatMap((k) => this.actor.system[k] || [])
      .map((e) => e.actorUuid)
      .filter((uuid) => uuid && uuid !== scenarioPoi);
    if (!allUuids.length) {
      ui.notifications.warn(game.i18n.localize("STA_TC.Wizard.NoPoisForEvent"));
      return;
    }
    const randomUuid = allUuids[Math.floor(Math.random() * allUuids.length)];
    await this._rollEventForPoi(randomUuid);
  }

  async _rollEventForPoi(poiUuid) {
    const tableUuid = game.settings.get(MODULE_ID, "tableEvents");
    if (!tableUuid) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.Wizard.EventTableNotConfigured"),
      );
      return;
    }
    const table = await fromUuid(tableUuid);
    if (!table) {
      ui.notifications.error(
        game.i18n.format("STA_TC.Poi.Generator.TableNotFound", {
          name: "Events",
        }),
      );
      return;
    }

    const roll = await table.roll();
    const result = roll.results?.[0];

    // Prefer a directly-referenced Event item document in the table result.
    let itemData = null;
    const docUuid = result?.documentUuid?.trim();
    if (docUuid) {
      const doc = await fromUuid(docUuid);
      if (doc?.documentName === "Item" && doc.type === `${MODULE_ID}.event`) {
        itemData = doc.toObject();
        for (const effect of itemData.effects ?? []) effect.transfer = true;
      }
    }

    // Fallback: build a minimal event from the roll result text.
    const resultText = result?.text || result?.name || "No result";
    const resultName =
      result?.name && result.name !== resultText
        ? result.name
        : resultText
            .split(/[.:!?]/)[0]
            .trim()
            .slice(0, 60);
    if (!itemData) {
      itemData = {
        name: resultName || game.i18n.localize("STA_TC.EventName"),
        type: `${MODULE_ID}.event`,
        system: { description: resultText },
      };
    }

    // Embed the event item on the PoI actor, enforcing the 1-event limit.
    const poi = await fromUuid(poiUuid);
    if (poi) {
      const existingIds = poi.items
        .filter((i) => i.type === `${MODULE_ID}.event`)
        .map((i) => i.id);
      if (existingIds.length)
        await poi.deleteEmbeddedDocuments("Item", existingIds);
      await poi.createEmbeddedDocuments("Item", [itemData]);
    }

    // Update the tracker entry's eventResult (drives the Roll/Reroll button label).
    const displayName = itemData.name;
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
      const idx = entries.findIndex((e) => e.actorUuid === poiUuid);
      if (idx !== -1) {
        entries[idx].eventResult = displayName;
        await this.actor.update({ [`system.${listKey}`]: entries });
        break;
      }
    }
  }

  // ==========================================================================
  // Action Handlers — Conflicts (Phase 2)
  // ==========================================================================

  static async _onRollConflict(event, target) {
    const poiUuid = target.dataset.uuid;
    if (!poiUuid) return;
    const poi = await fromUuid(poiUuid);
    if (!poi) return;
    const poiPower = poi.system?.power || "military";
    const poiPowerLabel = game.i18n.localize(
      `STA_TC.Powers.${this._capitalize(poiPower)}`,
    );
    const difficulty = poi.system?.difficulty || 1;
    const power2 = poi.system?.power2 || null;
    const difficulty2 = poi.system?.difficulty2 ?? 1;
    const powerLabel2 = power2
      ? game.i18n.localize(`STA_TC.Powers.${this._capitalize(power2)}`)
      : null;
    let primaryUuid = null,
      assistUuid = null;
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      for (const entry of this.actor.system[listKey] || []) {
        if (entry.actorUuid === poiUuid) {
          primaryUuid = entry.asset1Uuid;
          assistUuid = entry.asset2Uuid;
          break;
        }
      }
      if (primaryUuid !== null) break;
    }
    const primaryActor = primaryUuid ? await fromUuid(primaryUuid) : null;
    const assistActor = assistUuid ? await fromUuid(assistUuid) : null;
    if (!primaryActor) return;
    const primaryPowers = primaryActor.system?.powers?.[poiPower] || {
      value: 0,
      focus: 0,
    };
    const primaryPowers2 = power2
      ? primaryActor.system?.powers?.[power2] || { value: 0, focus: 0 }
      : null;
    const assistPowers = assistActor?.system?.powers?.[poiPower] || {
      value: 0,
      focus: 0,
    };
    const assistPowers2 =
      power2 && assistActor
        ? assistActor.system?.powers?.[power2] || { value: 0, focus: 0 }
        : null;
    const powerSelectSection = power2
      ? `<p style="margin:0 0 4px;"><strong>${poi.name}</strong></p>
      <p style="margin:0 0 4px;font-weight:bold;">${game.i18n.localize("STA_TC.Dialog.ChoosePower")}:</p>
      <label style="display:block;margin-bottom:4px;"><input type="radio" name="selectedPower" value="${poiPower}" checked> <strong>${poiPowerLabel} D${difficulty}</strong> &mdash; ${primaryActor.name}: ${poiPowerLabel} ${primaryPowers.value} / Focus ${primaryPowers.focus}</label>
      <label style="display:block;margin-bottom:4px;"><input type="radio" name="selectedPower" value="${power2}"> <strong>${powerLabel2} D${difficulty2}</strong> &mdash; ${primaryActor.name}: ${powerLabel2} ${primaryPowers2.value} / Focus ${primaryPowers2.focus}</label>`
      : `<p style="margin:0 0 2px;"><strong>${poi.name}</strong> &mdash; ${poiPowerLabel} &middot; ${game.i18n.localize("STA_TC.Wizard.Difficulty")}: ${difficulty}</p>
      <p style="margin:0 0 6px;"><em>${primaryActor.name}</em> &mdash; ${poiPowerLabel} ${primaryPowers.value} / Focus ${primaryPowers.focus}</p>`;
    const assistSection = assistActor
      ? `<hr style="margin:6px 0;">
      <p style="margin:0 0 2px;"><strong>${game.i18n.localize("STA_TC.Wizard.AssistingAsset")}</strong>: ${assistActor.name}${power2 ? "" : ` &mdash; ${poiPowerLabel} ${assistPowers.value} / Focus ${assistPowers.focus}`}</p>
      <div class="row"><div class="tracktitle">${game.i18n.localize("STA_TC.Dialog.UsingFocus")}</div><input type="checkbox" name="assistFocus" id="assistFocus" checked></div>`
      : "";

    // Render STA's own dice pool template for the standard roll options
    const staRoll = new STARoll();
    const calculatedComplicationRange = await staRoll._sceneComplications();
    const staDialogHTMLRaw =
      await foundry.applications.handlebars.renderTemplate(
        "systems/sta/templates/apps/dicepool-attribute2e.hbs",
        {
          calculatedComplicationRange,
          defaultValue: "2",
          starships: [],
          systems: [],
          departments: [],
        },
      );

    // Remove the "Is Ship Assisting" row/section (not relevant for campaign rolls)
    // and default the Focus checkbox to checked.
    const _doc = new DOMParser().parseFromString(staDialogHTMLRaw, "text/html");
    _doc.querySelector("#starshipAssisting")?.closest(".row")?.remove();
    _doc.querySelector(".starshipAssisting")?.remove();
    const _focusBox = _doc.querySelector("#usingFocus");
    if (_focusBox) _focusBox.setAttribute("checked", "checked");
    const staDialogHTML = _doc.body.innerHTML;

    const content = `<div style="padding:4px 8px 0;">${powerSelectSection}</div>${staDialogHTML}${assistSection ? `<div style="padding:0 8px;">${assistSection}</div>` : ""}`;

    const formData = await foundry.applications.api.DialogV2.wait({
      window: {
        title: `${game.i18n.localize("STA_TC.Wizard.RollConflict")}: ${poi.name}`,
      },
      position: { height: "auto", width: 375 },
      content,
      classes: ["dialogue"],
      buttons: [
        {
          action: "roll",
          default: true,
          label: game.i18n.localize("STA_TC.Wizard.RollConflict"),
          icon: "fas fa-dice-d20",
          callback: (_ev, _button, dialog) => {
            const form = dialog.element.querySelector("form");
            return form ? new FormData(form) : null;
          },
        },
      ],
      close: () => null,
    });
    if (!formData) return;
    const formValues = {
      diceCount: parseInt(formData.get("dicePoolSlider") || "2"),
      usingFocus: formData.get("usingFocus") === "on",
      usingDedicatedFocus: formData.get("usingDedicatedFocus") === "on",
      usingDetermination: formData.get("usingDetermination") === "on",
      complicationRange: parseInt(formData.get("complicationRange") || "1"),
      assistFocus: formData.get("assistFocus") === "on",
      selectedPower: formData.get("selectedPower") ?? null,
    };
    if (!formValues) return;
    const {
      diceCount,
      usingFocus,
      usingDedicatedFocus,
      usingDetermination,
      complicationRange,
      assistFocus,
      selectedPower,
    } = formValues;
    const chosenPower =
      selectedPower && selectedPower !== poiPower ? power2 : poiPower;
    const chosenDifficulty = chosenPower === power2 ? difficulty2 : difficulty;
    const chosenPrimaryPowers =
      chosenPower === power2 ? primaryPowers2 : primaryPowers;
    const chosenAssistPowers =
      chosenPower === power2 ? assistPowers2 : assistPowers;
    const primaryResult = await this._performRoll(
      diceCount,
      chosenPrimaryPowers.value,
      chosenPrimaryPowers.focus,
      usingFocus,
      usingDedicatedFocus,
      usingDetermination,
      complicationRange,
      primaryActor.name,
      poi.name,
      chosenPower,
    );
    const assistResult = assistActor
      ? await this._performRoll(
          1,
          chosenAssistPowers.value,
          chosenAssistPowers.focus,
          assistFocus,
          false,
          false,
          complicationRange,
          assistActor.name,
          poi.name,
          chosenPower,
        )
      : null;
    const totalSuccesses =
      primaryResult.successes + (assistResult?.successes || 0);
    const hadNat20 = primaryResult.hadNat20 || assistResult?.hadNat20 || false;
    await this._postConflictRollSummaryChat({
      poi,
      primaryActor,
      assistActor,
      chosenPower,
      primaryResult,
      assistResult,
      totalSuccesses,
    });
    // Store advisory data only — the GM must still click Pass or Fail to resolve.
    // conflictResult is intentionally left blank so the conflict stays unresolved.
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
      const idx = entries.findIndex((e) => e.actorUuid === poiUuid);
      if (idx !== -1) {
        entries[idx].conflictSuccesses = totalSuccesses;
        entries[idx].conflictHadNat20 = hadNat20;
        await this.actor.update({ [`system.${listKey}`]: entries });
        break;
      }
    }
  }

  static async _onSetConflictResult(event, target) {
    const poiUuid = target.dataset.uuid;
    const intent = target.dataset.result; // "success" or "failure"
    if (!poiUuid || !intent) return;
    // Load the POI to get difficulty for momentum calculation
    const poi = await fromUuid(poiUuid);
    const difficulty = poi?.system?.difficulty || 1;
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
      const idx = entries.findIndex((e) => e.actorUuid === poiUuid);
      if (idx !== -1) {
        const advisorySuccesses = entries[idx].conflictSuccesses || 0;
        const advisoryNat20 = entries[idx].conflictHadNat20 || false;
        // Derive result flavour from the GM's pass/fail intent + any advisory roll data
        let finalResult;
        let finalMomentum = 0;
        if (intent === "success") {
          finalMomentum = Math.max(0, advisorySuccesses - difficulty);
          if (advisoryNat20) {
            // Advisory roll already recorded a nat20 complication — auto flawed success.
            finalResult = "flawedSuccess";
          } else {
            // Ask the GM whether a complication was rolled.
            const isFlawed = await foundry.applications.api.DialogV2.wait({
              window: {
                title: game.i18n.localize("STA_TC.Wizard.RollConflict"),
              },
              content: `<p>${game.i18n.localize("STA_TC.Dialog.SuccessTypePrompt")}</p>`,
              buttons: [
                {
                  action: "flawed",
                  label: game.i18n.localize(
                    "STA_TC.Wizard.ResultFlawedSuccess",
                  ),
                  icon: "fas fa-exclamation-triangle",
                  default: false,
                  callback: () => true,
                },
                {
                  action: "success",
                  label: game.i18n.localize("STA_TC.Wizard.ResultSuccess"),
                  icon: "fas fa-check",
                  default: true,
                  callback: () => false,
                },
              ],
              rejectClose: false,
            });
            if (isFlawed === null) return;
            finalResult = isFlawed ? "flawedSuccess" : "success";
          }
        } else if (advisoryNat20) {
          // Built-in roll recorded a nat20 complication — auto serious setback.
          finalResult = "seriousSetback";
        } else {
          // No nat20 in advisory data; ask the GM whether a complication was rolled.
          const isSeriousSetback = await foundry.applications.api.DialogV2.wait(
            {
              window: {
                title: game.i18n.localize("STA_TC.Wizard.RollConflict"),
              },
              content: `<p>${game.i18n.localize("STA_TC.Dialog.FailureTypePrompt")}</p>`,
              buttons: [
                {
                  action: "serious",
                  label: game.i18n.localize(
                    "STA_TC.Wizard.ResultSeriousSetback",
                  ),
                  icon: "fas fa-skull",
                  default: false,
                  callback: () => true,
                },
                {
                  action: "failure",
                  label: game.i18n.localize("STA_TC.Wizard.ResultFailure"),
                  icon: "fas fa-times",
                  default: true,
                  callback: () => false,
                },
              ],
              rejectClose: false,
            },
          );
          if (isSeriousSetback === null) return;
          finalResult = isSeriousSetback ? "seriousSetback" : "failure";
        }
        entries[idx].conflictResult = finalResult;
        entries[idx].conflictMomentum = finalMomentum;
        await this.actor.update({ [`system.${listKey}`]: entries });
        // Notify conflict resolution
        const _conflictResultLabels = {
          success: "STA_TC.Wizard.ResultSuccess",
          flawedSuccess: "STA_TC.Wizard.ResultFlawedSuccess",
          failure: "STA_TC.Wizard.ResultFailure",
          seriousSetback: "STA_TC.Wizard.ResultSeriousSetback",
        };
        const _momentumStr =
          finalMomentum > 0
            ? ` (+${finalMomentum} ${game.i18n.localize("STA_TC.Wizard.MomentumGained")})`
            : "";
        await TrackerNotifier.emit({
          tracker: this.actor,
          event: "conflictFinalized",
          message: `${poi?.name || "?"}: ${game.i18n.localize(_conflictResultLabels[finalResult] || finalResult)}${_momentumStr}`,
          entityUuid: poiUuid,
          data: { result: finalResult, momentum: finalMomentum },
        });
        break;
      }
    }
  }

  static async _onResetConflictRoll(event, target) {
    const poiUuid = target.dataset.uuid;
    if (!poiUuid) return;
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
      const idx = entries.findIndex((e) => e.actorUuid === poiUuid);
      if (idx !== -1) {
        entries[idx].conflictResult = "";
        entries[idx].conflictSuccesses = 0;
        entries[idx].conflictMomentum = 0;
        entries[idx].conflictHadNat20 = false;
        entries[idx].consequenceChosen = "";
        entries[idx].failureChoice = "";
        entries[idx].lossResult = "";
        await this.actor.update({ [`system.${listKey}`]: entries });
        break;
      }
    }
  }

  static async _onChooseConsequence(event, target) {
    const poiUuid = target.dataset.uuid;
    const consequence = target.dataset.consequence;
    if (!poiUuid || !consequence) return;
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
      const idx = entries.findIndex((e) => e.actorUuid === poiUuid);
      if (idx === -1) continue;
      const updates = {};
      if (consequence === "extraPoi") {
        updates["system.turnExtraPoisNextTurn"] =
          (this.actor.system.turnExtraPoisNextTurn || 0) + 1;
        entries[idx].consequenceChosen = "extraPoi";
        const poiExtra = await fromUuid(poiUuid);
        await this._appendPendingNote(
          game.i18n.format("STA_TC.Wizard.NoteExtraPoi", {
            name: poiExtra?.name || "?",
          }),
        );
        ui.notifications.info(
          game.i18n.localize("STA_TC.Wizard.ConsequenceExtraPoi"),
        );
      } else if (consequence === "rollLoss") {
        await this._rollForLoss(poiUuid);
        entries[idx].consequenceChosen = "rollLoss";
      } else if (consequence === "increaseThreat") {
        const poi = await fromUuid(poiUuid);
        const amt = (poi?.system?.difficulty || 1) * 2;
        updates["system.turnThreatIncrease"] =
          (this.actor.system.turnThreatIncrease || 0) + amt;
        entries[idx].consequenceChosen = "increaseThreat";
        await this._appendPendingNote(
          game.i18n.format("STA_TC.Wizard.NoteIncreaseThreat", {
            amount: amt,
            name: poi?.name || "?",
          }),
        );
        ui.notifications.info(
          game.i18n.format("STA_TC.Wizard.ConsequenceIncreaseThreat", {
            amount: amt,
          }),
        );
      }
      updates[`system.${listKey}`] = entries;
      await this.actor.update(updates);
      break;
    }
  }

  static async _onChooseFailureOption(event, target) {
    const poiUuid = target.dataset.uuid;
    const option = target.dataset.option;
    if (!poiUuid || !option) return;
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
      const idx = entries.findIndex((e) => e.actorUuid === poiUuid);
      if (idx === -1) continue;
      if (option === "withdraw") entries[idx].failureChoice = "withdraw";
      if (option === "succeedAtCost") {
        entries[idx].conflictResult = "flawedSuccess";
        entries[idx].failureChoice = "succeedAtCost";
      }
      await this.actor.update({ [`system.${listKey}`]: entries });
      break;
    }
  }

  // ==========================================================================
  // Action Handlers — Phase 3 Outcomes
  // ==========================================================================

  static async _onPhase3Next(event, target) {
    const current = this.actor.system.turnStep || 1;
    if (current >= 4) return;
    await this.actor.update({ "system.turnStep": current + 1 });
  }

  static async _onPhase3Prev(event, target) {
    const current = this.actor.system.turnStep || 1;
    if (current <= 1) return;
    await this.actor.update({ "system.turnStep": current - 1 });
  }

  static async _onRollEscalation(event, target) {
    const listKey = target.dataset.listKey;
    const entryIndex = parseInt(target.dataset.entryIndex);
    if (!listKey || isNaN(entryIndex)) return;
    const tableUuid = game.settings.get(MODULE_ID, "tableEscalation");
    if (!tableUuid) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.Wizard.EscalationTableNotConfigured"),
      );
      return;
    }
    const table = await fromUuid(tableUuid);
    if (!table) {
      ui.notifications.error(
        game.i18n.format("STA_TC.Poi.Generator.TableNotFound", {
          name: "Escalation",
        }),
      );
      return;
    }
    const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
    if (!entries[entryIndex]) return;
    const roll = await table.roll();
    const result = roll.results?.[0];
    entries[entryIndex].escalationRolled = true;
    await this.actor.update({ [`system.${listKey}`]: entries });
    const poi = await fromUuid(entries[entryIndex].actorUuid);
    const headerLabel = poi?.name
      ? `${game.i18n.localize("STA_TC.Wizard.EscalationResult")} — ${poi.name}`
      : game.i18n.localize("STA_TC.Wizard.EscalationResult");
    const content = await CampaignTrackerSheet._buildResultCard({
      result,
      headerLabel,
      accent: "#e67e22",
    });
    await ChatMessage.create({
      content,
      speaker: { alias: game.i18n.localize("STA_TC.Wizard.SpeakerAlias") },
      whisper: [game.user.id],
    });
  }

  static async _onRollCommandeer(event, target) {
    const listKey = target.dataset.listKey;
    const entryIndex = parseInt(target.dataset.entryIndex);
    if (!listKey || isNaN(entryIndex)) return;
    const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
    if (!entries[entryIndex]) return;
    // Don't overwrite a previously commandeered asset
    if (entries[entryIndex].commandeeredAssetUuid) return;
    const system = this.actor.system;
    // Exclude assets commandeered in prior turns AND assets already picked by
    // other routine POI rolls earlier this same turn.
    const excludedUuids = new Set([
      ...(system.commandeeredAssets || []),
      ...(system.poiListRoutine || [])
        .map((e) => e.commandeeredAssetUuid)
        .filter(Boolean),
    ]);
    const pool = [
      ...(system.characterAssets || []),
      ...(system.shipAssets || []),
      ...(system.resourceAssets || []),
    ].filter((uuid) => !excludedUuids.has(uuid));
    if (!pool.length) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.Wizard.NoAssetsToCommandeer"),
      );
      return;
    }
    const chosenUuid = pool[Math.floor(Math.random() * pool.length)];
    const asset = await fromUuid(chosenUuid);
    entries[entryIndex].commandeeredAssetUuid = chosenUuid;
    entries[entryIndex].outcomeConfirmed = true;
    await this.actor.update({ [`system.${listKey}`]: entries });
    const commandeerMsg = game.i18n.format("STA_TC.Wizard.AssetCommandeered", {
      name: asset?.name || chosenUuid,
    });
    await TrackerNotifier.emit({
      tracker: this.actor,
      event: "phase3Commandeer",
      message: commandeerMsg,
      entityUuid: chosenUuid,
    });
  }

  // ==========================================================================
  // Helpers — Notes
  // ==========================================================================

  async _appendPendingNote(text) {
    const current = this.actor.system.turnPendingNotes || "";
    const updated = current ? `${current}\n${text}` : text;
    await this.actor.update({ "system.turnPendingNotes": updated });
  }

  // ==========================================================================
  // Action Handlers — Phase 3 Outcome Buttons
  // ==========================================================================

  static async _onConfirmOutcomeResolved(event, target) {
    const listKey = target.dataset.listKey;
    const entryIndex = parseInt(target.dataset.entryIndex);
    if (!listKey || isNaN(entryIndex)) return;
    const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
    if (!entries[entryIndex]) return;
    const actorUuid = entries[entryIndex].actorUuid;
    const poiActor = actorUuid ? await fromUuid(actorUuid) : null;
    const deleteActor = await CampaignTrackerSheet._confirmRemove(
      poiActor?.name ?? "",
    );
    if (deleteActor === null) return;
    entries.splice(entryIndex, 1);
    await this.actor.update({ [`system.${listKey}`]: entries });
    if (deleteActor && poiActor) await poiActor.delete();
    ui.notifications.info(game.i18n.localize("STA_TC.Wizard.Resolved"));
  }

  static async _onConfirmOutcomeIntensify(event, target) {
    const listKey = target.dataset.listKey;
    const entryIndex = parseInt(target.dataset.entryIndex);
    if (!listKey || isNaN(entryIndex)) return;
    const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
    if (!entries[entryIndex]) return;
    const poiActorUuid = entries[entryIndex].actorUuid;
    const poi = await fromUuid(poiActorUuid);
    let notifyMsg = game.i18n.localize("STA_TC.Wizard.OutcomeIntensify1Short");
    if (poi) {
      const urgency = poi.system?.urgency || 1;
      const oldDiff = poi.system?.difficulty || 1;
      const poiUpdates = {
        "system.urgency": Math.min(5, urgency + 1),
        "system.difficulty": Math.min(5, oldDiff + 1),
      };
      if (poi.system?.difficulty2 != null)
        poiUpdates["system.difficulty2"] = Math.min(
          5,
          poi.system.difficulty2 + 1,
        );
      await poi.update(poiUpdates);
      notifyMsg = game.i18n.format("STA_TC.Notify.Phase3Intensify", {
        name: poi.name,
        oldUrgency: urgency,
        newUrgency: Math.min(5, urgency + 1),
        oldDiff,
        newDiff: Math.min(5, oldDiff + 1),
      });
    }
    entries[entryIndex].outcomeConfirmed = true;
    await this.actor.update({ [`system.${listKey}`]: entries });
    await TrackerNotifier.emit({
      tracker: this.actor,
      event: "phase3Intensify",
      message: notifyMsg,
      entityUuid: poiActorUuid,
    });
  }

  static async _onConfirmOutcomeCatastrophe(event, target) {
    const listKey = target.dataset.listKey;
    const entryIndex = parseInt(target.dataset.entryIndex);
    if (!listKey || isNaN(entryIndex)) return;
    const system = this.actor.system;
    const entries = foundry.utils.deepClone(system[listKey] || []);
    if (!entries[entryIndex]) return;
    const catastrophePoi = await fromUuid(entries[entryIndex].actorUuid);
    entries.splice(entryIndex, 1);
    await this.actor.update({
      [`system.${listKey}`]: entries,
      "system.pace": (system.pace || 0) + 1,
    });
    await TrackerNotifier.emit({
      tracker: this.actor,
      event: "phase3Catastrophe",
      message: `${catastrophePoi?.name || "?"}: ${game.i18n.localize("STA_TC.Wizard.OutcomeCatastropheShort")} (${game.i18n.localize("STA_TC.CampaignTracker.Pace")} ${system.pace || 0}\u2192${(system.pace || 0) + 1})`,
    });
  }

  static async _onConfirmOutcomeDiffIncrease(event, target) {
    const listKey = target.dataset.listKey;
    const entryIndex = parseInt(target.dataset.entryIndex);
    if (!listKey || isNaN(entryIndex)) return;
    const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
    if (!entries[entryIndex]) return;
    const diffPoiUuid = entries[entryIndex].actorUuid;
    const poi = await fromUuid(diffPoiUuid);
    let diffNotifyMsg = game.i18n.localize(
      "STA_TC.Wizard.OutcomeExplorationDiffShort",
    );
    if (poi) {
      const oldDiff = poi.system?.difficulty || 1;
      const poiUpdates = {
        "system.missedCount": 1,
        "system.difficulty": Math.min(5, oldDiff + 1),
      };
      if (poi.system?.difficulty2 != null)
        poiUpdates["system.difficulty2"] = Math.min(
          5,
          poi.system.difficulty2 + 1,
        );
      await poi.update(poiUpdates);
      diffNotifyMsg = game.i18n.format("STA_TC.Notify.Phase3DiffIncrease", {
        name: poi.name,
        oldDiff,
        newDiff: Math.min(5, oldDiff + 1),
      });
    }
    entries[entryIndex].outcomeConfirmed = true;
    await this.actor.update({ [`system.${listKey}`]: entries });
    await TrackerNotifier.emit({
      tracker: this.actor,
      event: "phase3DiffIncrease",
      message: diffNotifyMsg,
      entityUuid: diffPoiUuid,
    });
  }

  static async _onConfirmOutcomeExplorationRemove(event, target) {
    const listKey = target.dataset.listKey;
    const entryIndex = parseInt(target.dataset.entryIndex);
    if (!listKey || isNaN(entryIndex)) return;
    const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
    if (!entries[entryIndex]) return;
    const removePoiUuid = entries[entryIndex].actorUuid;
    const removePoi = await fromUuid(removePoiUuid);
    entries.splice(entryIndex, 1);
    await this.actor.update({ [`system.${listKey}`]: entries });
    await TrackerNotifier.emit({
      tracker: this.actor,
      event: "phase3ExplorationRemove",
      message: `${removePoi?.name || "?"}: ${game.i18n.localize("STA_TC.Wizard.OutcomeExplorationRemovedShort")}`,
    });
  }

  static async _onConfirmOutcomeExtraPoi(event, target) {
    const listKey = target.dataset.listKey;
    const entryIndex = parseInt(target.dataset.entryIndex);
    if (!listKey || isNaN(entryIndex)) return;
    const system = this.actor.system;
    const entries = foundry.utils.deepClone(system[listKey] || []);
    if (!entries[entryIndex]) return;
    const poi = await fromUuid(entries[entryIndex].actorUuid);
    await this._appendPendingNote(
      game.i18n.format("STA_TC.Wizard.NoteExtraPoi", {
        name: poi?.name || "?",
      }),
    );
    entries[entryIndex].outcomeConfirmed = true;
    await this.actor.update({
      [`system.${listKey}`]: entries,
      "system.turnExtraPoisNextTurn": (system.turnExtraPoisNextTurn || 0) + 1,
    });
    await TrackerNotifier.emit({
      tracker: this.actor,
      event: "phase3ExtraPoi",
      message: `${poi?.name || "?"}: ${game.i18n.localize("STA_TC.Wizard.OutcomeUnknownShort")}`,
      entityUuid: entries[entryIndex]?.actorUuid ?? "",
    });
  }

  static async _onIgnoreOutcome(event, target) {
    const listKey = target.dataset.listKey;
    const entryIndex = parseInt(target.dataset.entryIndex);
    if (!listKey || isNaN(entryIndex)) return;
    const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
    if (!entries[entryIndex]) return;
    const entry = entries[entryIndex];
    const ignoredPoiUuid = entry.actorUuid;
    entry.conflictResult = "";
    entry.conflictSuccesses = 0;
    entry.conflictMomentum = 0;
    entry.conflictHadNat20 = false;
    entry.consequenceChosen = "";
    entry.failureChoice = "";
    entry.lossResult = "";
    entry.escalationRolled = false;
    entry.commandeeredAssetUuid = "";
    entry.outcomeConfirmed = false;
    entry.outcomeIgnored = true;
    await this.actor.update({ [`system.${listKey}`]: entries });
    await TrackerNotifier.emit({
      tracker: this.actor,
      event: "phase3Ignore",
      message: game.i18n.localize("STA_TC.Wizard.OutcomeIgnored"),
      entityUuid: ignoredPoiUuid,
    });
  }

  static async _onConfirmProgression(event, target) {
    const system = this.actor.system;
    if (system.turnProgressionConfirmed) return;

    const resolvedExplorationCount = (system.poiListExploration || []).filter(
      (e) =>
        e.conflictResult === "success" || e.conflictResult === "flawedSuccess",
    ).length;
    const fromExploration = resolvedExplorationCount * 3;
    const fromMomentum = system.turnMomentumSpent || 0;
    const roleplayBonus = system.turnRoleplayBonus || 0;
    const progressionGain = fromExploration + fromMomentum + roleplayBonus;
    const newTotal = (system.progression || 0) + progressionGain;

    const updates = {
      "system.progression": newTotal,
      "system.turnProgressionConfirmed": true,
    };
    if (fromMomentum > 0) {
      updates["system.campaignMomentum"] = Math.max(
        0,
        (system.campaignMomentum || 0) - fromMomentum,
      );
    }
    await this.actor.update(updates);
    await TrackerNotifier.emit({
      tracker: this.actor,
      event: "progressionConfirmed",
      message: game.i18n.format("STA_TC.Wizard.ProgressionConfirmed", {
        gain: progressionGain,
        total: newTotal,
      }),
    });
  }

  static async _onRollProgression(event, target) {
    const system = this.actor.system;
    const currentProgression = system.progression || 0;
    if (currentProgression < 5) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.Wizard.NotEnoughProgression"),
      );
      return;
    }
    const tableUuid = game.settings.get(MODULE_ID, "tableProgression");
    if (!tableUuid) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.Wizard.ProgressionTableNotConfigured"),
      );
      return;
    }
    const table = await fromUuid(tableUuid);
    if (!table) {
      ui.notifications.error(
        game.i18n.format("STA_TC.Poi.Generator.TableNotFound", {
          name: "Progression",
        }),
      );
      return;
    }
    const roll = await table.roll();
    const result = roll.results?.[0];
    if (!result) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.Wizard.NoProgressionResults"),
      );
      return;
    }
    await this.actor.update({
      "system.progression": currentProgression - 5,
    });
    await CampaignTrackerSheet._applyProgressionResult(result, this);
  }

  static async _onChooseProgression(event, target) {
    const system = this.actor.system;
    const currentProgression = system.progression || 0;
    if (currentProgression < 5) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.Wizard.NotEnoughProgression"),
      );
      return;
    }

    const tableUuid = game.settings.get(MODULE_ID, "tableProgression");
    if (!tableUuid) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.Wizard.ProgressionTableNotConfigured"),
      );
      return;
    }
    const table = await fromUuid(tableUuid);
    if (!table) {
      ui.notifications.error(
        game.i18n.format("STA_TC.Poi.Generator.TableNotFound", {
          name: "Progression",
        }),
      );
      return;
    }
    const results = Array.from(table.results?.contents ?? table.results ?? []);
    if (!results.length) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.Wizard.NoProgressionResults"),
      );
      return;
    }

    const rows = results
      .map((r, i) => {
        const label = foundry.utils.escapeHTML(
          r.text || r.name || `Result ${i + 1}`,
        );
        return `<label class="asset-picker-row">
          <input type="radio" name="progressionIdx" value="${i}" ${i === 0 ? "checked" : ""} />
          <span class="asset-picker-name">${label}</span>
        </label>`;
      })
      .join("");

    const idx = await foundry.applications.api.DialogV2.prompt({
      window: {
        title: game.i18n.localize("STA_TC.Wizard.ChooseProgression"),
      },
      content: `<div class="asset-picker-list">${rows}</div>`,
      ok: {
        label: game.i18n.localize("STA_TC.Converter.Confirm"),
        callback: (_ev, button) => button.form.elements.progressionIdx.value,
      },
      rejectClose: false,
    });

    if (idx === null || idx === undefined) return;
    const result = results[parseInt(idx)];
    if (!result) return;
    await this.actor.update({
      "system.progression": currentProgression - 5,
    });
    await CampaignTrackerSheet._applyProgressionResult(result, this);
  }

  /**
   * Build a rich chat-card body for a rolled/selected roll table result.
   * Resolves the linked item (if any) to show its name, effect text, image,
   * and a draggable Foundry content link.
   *
   * @param {object} opts
   * @param {TableResult} opts.result - The roll table result.
   * @param {string} opts.headerLabel - Card header text.
   * @param {string} opts.accent - Accent colour (CSS).
   * @returns {Promise<string>} HTML string.
   */
  static async _buildResultCard({ result, headerLabel, accent }) {
    let name = result?.text || result?.name || "";
    let effect = "";
    let img = result?.img || result?.icon || "";
    let uuid = result?.documentUuid || "";

    if (uuid) {
      const doc = await fromUuid(uuid);
      if (doc) {
        name = doc.name || name;
        effect = doc.system?.effect || "";
        img = doc.img || img;
        uuid = doc.uuid;
      }
    }
    if (!name) name = game.i18n.localize("STA_TC.Types.Progression");

    const safeName = foundry.utils.escapeHTML(name);
    const safeHeader = foundry.utils.escapeHTML(headerLabel);
    const imgHtml = img
      ? `<img src="${img}" alt="" style="width:44px;height:44px;object-fit:cover;border:none;border-radius:4px;flex:0 0 auto;" />`
      : "";
    const effectHtml = effect
      ? `<div style="margin-top:6px;line-height:1.4;">${effect}</div>`
      : "";
    // @UUID[...] is auto-enriched into a draggable content link in chat.
    const linkHtml = uuid
      ? `<div style="margin-top:8px;font-size:0.9em;opacity:0.9;">@UUID[${uuid}]{${safeName}}</div>`
      : "";

    return `<div style="border-left:4px solid ${accent};background:rgba(0,0,0,0.25);border-radius:6px;padding:10px;">
      <div style="font-weight:bold;color:${accent};text-transform:uppercase;font-size:0.8em;letter-spacing:0.5px;margin-bottom:6px;">${safeHeader}</div>
      <div style="display:flex;gap:8px;align-items:flex-start;">
        ${imgHtml}
        <div style="flex:1;">
          <div style="font-weight:bold;font-size:1.05em;">${safeName}</div>
          ${effectHtml}
          ${linkHtml}
        </div>
      </div>
    </div>`;
  }

  /**
   * Post a rich chat card for a progression roll result. No automation is
   * applied; the effect text comes from the linked progression item.
   *
   * @param {TableResult} result - The rolled/selected roll table result.
   * @param {CampaignTrackerSheet} sheet
   */
  static async _applyProgressionResult(result, sheet) {
    const content = await CampaignTrackerSheet._buildResultCard({
      result,
      headerLabel: game.i18n.localize("STA_TC.Wizard.RollProgression"),
      accent: "#3498db",
    });
    await ChatMessage.create({
      content,
      speaker: { alias: game.i18n.localize("STA_TC.Wizard.SpeakerAlias") },
      whisper: [game.user.id],
    });
  }

  // =========================================================================
  // Dice & Roll Methods
  // =========================================================================

  async _performRoll(
    diceCount,
    powerValue,
    focusValue,
    usingFocus,
    usingDedicatedFocus,
    usingDetermination,
    complicationRange,
    speakerName,
    poiName,
    power,
  ) {
    let focusRange = usingFocus ? focusValue : 0;
    if (usingDedicatedFocus) focusRange *= 2;
    let actualDice = diceCount,
      successes = 0,
      hadNat20 = false;
    if (usingDetermination && actualDice > 0) {
      successes += 2;
      actualDice -= 1;
    }
    const rolls = [];
    let roll = null;
    if (actualDice > 0) {
      roll = await new Roll(`${actualDice}d20`).evaluate();
      for (const die of roll.dice[0].results) {
        const val = die.result;
        rolls.push(val);
        if (val >= 21 - complicationRange) hadNat20 = true;
        if (val <= powerValue) {
          successes += 1;
          if (val <= focusRange) successes += 1;
        }
      }
    }
    const powerLabel = game.i18n.localize(
      `STA_TC.Powers.${this._capitalize(power)}`,
    );
    return {
      successes,
      hadNat20,
      rolls,
      roll,
      targetNumber: powerValue,
      focusRange,
      complicationRange,
      usedDetermination: usingDetermination,
      powerLabel,
      speakerName,
      poiName,
    };
  }

  async _postConflictRollSummaryChat({
    poi,
    primaryActor,
    assistActor,
    chosenPower,
    primaryResult,
    assistResult,
    totalSuccesses,
  }) {
    const powerLabel = game.i18n.localize(
      `STA_TC.Powers.${this._capitalize(chosenPower)}`,
    );

    // Build STA-style dice HTML: max (gold) = focus/crit, min (red) = complication
    const buildDiceString = (r) => {
      if (!r) return "";
      let html = "";
      if (r.usedDetermination) {
        html += `<li class="roll die d20 max">1</li>`;
      }
      for (const val of r.rolls ?? []) {
        if ((r.focusRange > 0 && val <= r.focusRange) || val === 1) {
          html += `<li class="roll die d20 max">${val}</li>`;
        } else if (val <= r.targetNumber) {
          html += `<li class="roll die d20">${val}</li>`;
        } else if (val >= 21 - (r.complicationRange ?? 1)) {
          html += `<li class="roll die d20 min">${val}</li>`;
        } else {
          html += `<li class="roll die d20">${val}</li>`;
        }
      }
      return html;
    };

    const buildRollDetails = (r) => {
      const parts = [];
      if (r?.usedDetermination)
        parts.push(game.i18n.localize("STA_TC.Dialog.UsingDetermination"));
      if (r?.focusRange > 0)
        parts.push(game.i18n.localize("STA_TC.Dialog.UsingFocus"));
      return parts.join(", ");
    };

    const countComplications = (r) =>
      (r?.rolls ?? []).filter((v) => v >= 21 - (r?.complicationRange ?? 1))
        .length;
    const totalComplications =
      countComplications(primaryResult) + countComplications(assistResult);

    // Use STA's own i18n keys for the success/complication summary lines
    const successText =
      totalSuccesses === 1
        ? `1 ${game.i18n.localize("sta.roll.success")}`
        : `${totalSuccesses} ${game.i18n.localize("sta.roll.successPlural")}`;
    const complicationText =
      totalComplications === 1
        ? `1 ${game.i18n.localize("sta.roll.complication")}`
        : totalComplications > 1
          ? `${totalComplications} ${game.i18n.localize("sta.roll.complicationPlural")}`
          : "";

    const dicePool =
      (primaryResult.rolls?.length ?? 0) +
      (primaryResult.usedDetermination ? 1 : 0);

    // Use the NPC template (crew + ship layout) when there is an assisting asset,
    // otherwise fall back to the standard single-actor task template.
    const useNpcTemplate = !!assistActor;
    const templatePath = useNpcTemplate
      ? "systems/sta/templates/chat/attribute-test-npc.hbs"
      : "systems/sta/templates/chat/attribute-test.hbs";

    const templateData = useNpcTemplate
      ? {
          speakerName: primaryActor?.name ?? "-",
          flavor: powerLabel,
          dicePool,
          checkTarget: primaryResult.targetNumber,
          complicationMinimumValue: 20,
          rollDetails: buildRollDetails(primaryResult),
          diceString: buildDiceString(primaryResult),
          starshipName: assistActor.name,
          flavorship: powerLabel,
          checkTargetship: assistResult?.targetNumber ?? 0,
          diceStringship: buildDiceString(assistResult),
          successText,
          complicationText,
        }
      : {
          speakerName: primaryActor?.name ?? "-",
          flavor: powerLabel,
          dicePool,
          checkTarget: primaryResult.targetNumber,
          complicationMinimumValue: 20,
          rollDetails: buildRollDetails(primaryResult),
          diceString: buildDiceString(primaryResult),
          successText,
          complicationText,
        };

    const rollHTML = await foundry.applications.handlebars.renderTemplate(
      templatePath,
      templateData,
    );

    const rolls = [];
    if (primaryResult?.roll) rolls.push(primaryResult.roll);
    if (assistResult?.roll) rolls.push(assistResult.roll);

    await ChatMessage.create({
      rolls,
      content: rollHTML,
      speaker: { alias: game.i18n.localize("STA_TC.Wizard.SpeakerAlias") },
      whisper: game.users.contents.filter((u) => u.isGM).map((u) => u.id),
      flags: {
        sta: {
          rollType: useNpcTemplate ? "npc" : "task",
          speakerName: primaryActor?.name ?? "-",
          starshipName: assistActor?.name ?? undefined,
          flavor: powerLabel,
          flavorship: useNpcTemplate ? powerLabel : undefined,
          dicePool,
          checkTarget: primaryResult.targetNumber,
          checkTargetship: assistResult?.targetNumber ?? 0,
          complicationMinimumValue: 20,
          disDepTarget: primaryResult.focusRange,
          shipdisDepTarget: assistResult?.focusRange ?? 0,
          usingFocus: primaryResult.focusRange > 0,
          usingDedicatedFocus: false,
          diceOutcome: [...(primaryResult.rolls ?? [])],
          shipdiceOutcome: assistResult
            ? [...(assistResult.rolls ?? [])]
            : undefined,
        },
        "sta-tactical-campaign": {
          poiUuid: poi.uuid,
          trackerActorId: this.actor.id,
          primaryTargetNumber: primaryResult.targetNumber,
          primaryFocusRange: primaryResult.focusRange,
          primaryUsedDetermination: primaryResult.usedDetermination ?? false,
          assistTargetNumber: assistResult?.targetNumber ?? 0,
          assistFocusRange: assistResult?.focusRange ?? 0,
          assistUsedDetermination: assistResult?.usedDetermination ?? false,
          hasAssist: !!assistActor,
        },
      },
    });
  }

  // ==========================================================================
  // Active-Effect helpers for asset unavailability
  // ==========================================================================

  /**
   * Apply (or replace) an "unavailable" Active Effect on an asset actor.
   * The AE stores the campaign turn at which it should auto-expire so that
   * _onStartTurn can clean it up without relying on world-time.
   *
   * @param {string} actorUuid       - UUID of the asset actor
   * @param {string} label           - Human-readable reason (shown as AE name)
   * @param {number} expireAfterTurn - Campaign turn number at which the AE should be removed
   */
  async _applyUnavailableEffect(actorUuid, label, expireAfterTurn) {
    const actor = await fromUuid(actorUuid);
    if (!actor) return;
    await replaceAssetStatusEffect(actor, "unavailable", {
      name: label || game.i18n.localize("STA_TC.Wizard.UnavailableStatus"),
      expireAfterTurn,
    });
  }

  /**
   * GM action: manually remove the unavailable AE from an asset actor.
   */
  static async _onClearUnavailable(event, target) {
    const uuid =
      target.closest("[data-uuid]")?.dataset.uuid ?? target.dataset.uuid;
    const actor = await fromUuid(uuid);
    if (!actor) return;
    const ae = actor.effects.find((e) => e.flags?.[MODULE_ID]?.unavailable);
    if (ae) await ae.delete();
    ui.notifications.info(
      game.i18n.format("STA_TC.Wizard.UnavailableCleared", {
        name: actor.name,
      }),
    );
    this.render();
  }

  /**
   * Open the Progression Log popup for this campaign tracker.
   */
  static _onOpenProgressionLog(event, target) {
    ProgressionLog.open(this.actor);
  }

  /**
   * Open the Turn Log popup for this campaign tracker.
   */
  static _onOpenTurnLog(event, target) {
    TurnLog.open(this.actor);
  }

  /**
   * Open the roll table sheet for a PoI type, using the UUID from game settings.
   */
  static async _onOpenPoiTable(event, target) {
    const tableKey = target.dataset.tableKey;
    const uuid = game.settings.get(MODULE_ID, tableKey);
    if (!uuid) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.CampaignTracker.NoPoiTableConfigured"),
      );
      return;
    }
    const table = await fromUuid(uuid);
    if (!table) {
      ui.notifications.warn(
        game.i18n.localize("STA_TC.CampaignTracker.PoiTableNotFound"),
      );
      return;
    }
    table.sheet.render(true);
  }

  /**
   * Set a single POI's visibility state.
   * Reads data-visibility="hidden|masked|revealed" from the clicked element.
   */
  static async _onSetPoiVisibility(event, target) {
    const state = target.dataset.visibility;
    const uuid = target.closest("[data-uuid]").dataset.uuid;
    const poi = await fromUuid(uuid);
    if (!poi) return;
    const updates = {
      hidden: { "system.hiddenByGM": true },
      masked: { "system.hiddenByGM": false, "system.revealed": false },
      revealed: { "system.hiddenByGM": false, "system.revealed": true },
    }[state];
    if (updates) await poi.update(updates);
  }

  /**
   * Bulk: set all generated POIs to a given visibility state.
   * Reads data-visibility="hidden|masked|revealed" from the clicked element.
   */
  static async _onSetAllPoiVisibility(event, target) {
    const state = target.dataset.visibility;
    const updates = {
      hidden: { "system.hiddenByGM": true },
      masked: { "system.hiddenByGM": false, "system.revealed": false },
      revealed: { "system.hiddenByGM": false, "system.revealed": true },
    }[state];
    if (!updates) return;
    const uuids = this.actor.system.turnGeneratedPois || [];
    for (const uuid of uuids) {
      const poi = await fromUuid(uuid);
      if (poi) await poi.update(updates);
    }
  }

  async _rollForLoss(poiUuid) {
    let primaryUuid = null;
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      for (const entry of this.actor.system[listKey] || []) {
        if (entry.actorUuid === poiUuid) {
          primaryUuid = entry.asset1Uuid;
          break;
        }
      }
      if (primaryUuid) break;
    }
    const primaryActor = primaryUuid ? await fromUuid(primaryUuid) : null;
    const assetType = primaryActor?.system?.assetType || "character";

    // Roll 1d20 for loss outcome
    const roll = await new Roll("1d20").evaluate();
    const rollValue = roll.total;

    let resultTitle;
    let resultDesc;
    let markLost = false;
    let markUnavailable = false;

    if (assetType === "ship") {
      if (rollValue === 1) {
        resultTitle = game.i18n.localize(
          "STA_TC.Wizard.LossOutcome.ShipLostAllHands",
        );
        resultDesc = game.i18n.localize(
          "STA_TC.Wizard.LossOutcome.ShipLostAllHandsDesc",
        );
        markLost = true;
      } else if (rollValue <= 4) {
        resultTitle = game.i18n.localize(
          "STA_TC.Wizard.LossOutcome.ShipBeyondRecovery",
        );
        resultDesc = game.i18n.localize(
          "STA_TC.Wizard.LossOutcome.ShipBeyondRecoveryDesc",
        );
        markLost = true;
      } else if (rollValue <= 12) {
        resultTitle = game.i18n.localize(
          "STA_TC.Wizard.LossOutcome.ShipDamaged",
        );
        resultDesc = game.i18n.localize(
          "STA_TC.Wizard.LossOutcome.ShipDamagedDesc",
        );
        markUnavailable = true;
      } else {
        resultTitle = game.i18n.localize("STA_TC.Wizard.LossOutcome.ShipMinor");
        resultDesc = game.i18n.localize(
          "STA_TC.Wizard.LossOutcome.ShipMinorDesc",
        );
      }
    } else {
      if (rollValue <= 2) {
        resultTitle = game.i18n.localize("STA_TC.Wizard.LossOutcome.CharMIA");
        resultDesc = game.i18n.localize(
          "STA_TC.Wizard.LossOutcome.CharMIADesc",
        );
        markLost = true;
      } else if (rollValue <= 10) {
        resultTitle = game.i18n.localize(
          "STA_TC.Wizard.LossOutcome.CharInjured",
        );
        resultDesc = game.i18n.localize(
          "STA_TC.Wizard.LossOutcome.CharInjuredDesc",
        );
        markUnavailable = true;
      } else {
        resultTitle = game.i18n.localize("STA_TC.Wizard.LossOutcome.CharNone");
        resultDesc = game.i18n.localize(
          "STA_TC.Wizard.LossOutcome.CharNoneDesc",
        );
      }
    }

    if (markLost && primaryActor) {
      await replaceAssetStatusEffect(primaryActor, "lost", {
        name: resultTitle,
      });
    }

    const resultText = resultTitle;
    for (const listKey of [
      "poiListThreat",
      "poiListExploration",
      "poiListRoutine",
      "poiListUnknown",
    ]) {
      const entries = foundry.utils.deepClone(this.actor.system[listKey] || []);
      const idx = entries.findIndex((e) => e.actorUuid === poiUuid);
      if (idx !== -1) {
        entries[idx].lossResult = resultText;
        await this.actor.update({ [`system.${listKey}`]: entries });
        break;
      }
    }
    const allHandsNote =
      markLost && assetType === "ship" && rollValue === 1
        ? `<p style="font-size:0.85em;color:#ffaaa0;margin-top:6px;"><i class="fas fa-exclamation-triangle"></i> Any Character assets assigned to this ship's mission should also be marked Lost.</p>`
        : "";
    await ChatMessage.create({
      content: `<div style="background:#333;border-radius:8px;padding:10px;color:#eee;border-left:4px solid #e74c3c;">
        <h3 style="margin:0 0 6px;color:#e74c3c;">&#x1F480; ${game.i18n.localize("STA_TC.RollForLoss")} \u2014 ${rollValue}/20</h3>
        <p><strong>${primaryActor?.name || "Asset"}:</strong> <em>${resultTitle}</em></p>
        <p style="font-size:0.9em;opacity:0.8;margin-top:4px;">${resultDesc}</p>${allHandsNote}
      </div>`,
      speaker: { alias: game.i18n.localize("STA_TC.Wizard.SpeakerAlias") },
      whisper: [game.user.id],
    });
    // Apply an unavailability AE to the primary asset actor when the result
    // is "unavailable" (not lost, not minor).
    if (primaryUuid && markUnavailable) {
      const expireAfterTurn = (this.actor.system.campaignTurnNumber || 0) + 1;
      await this._applyUnavailableEffect(
        primaryUuid,
        resultText,
        expireAfterTurn,
      );
    }
  }

  // ==========================================================================
  // Utility
  // ==========================================================================

  _capitalize(str) {
    if (!str) return "";
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
}
